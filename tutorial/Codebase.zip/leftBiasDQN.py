import gymnasium as gym
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import random

# ==========================================
# Left-Biased DQN Tutorial (CartPole)
# ==========================================
# This implementation includes practical fixes and optimizations for training a DQN on CartPole.
# Comments explain purpose and trade-offs for each component.

# --- CONFIGURATION ---
ENV_NAME = "CartPole-v1"
LEARNING_RATE = 1e-3       # Slightly higher for faster convergence
GAMMA = 0.99
EPSILON_START = 1.0
EPSILON_END = 0.01
EPSILON_DECAY = 0.995
MEMORY_SIZE = 10000
BATCH_SIZE = 64
MIN_MEMORY_SIZE = 1000     # CRITICAL FIX: Don't train until we have this many samples
TARGET_UPDATE = 10 

device = torch.device("cpu") # Force CPU for speed on small state space

# --- 1. VECTORIZED MEMORY ---
class FastBuffer:
    """
    A simple, pre-allocated replay buffer backed by numpy arrays.
    This avoids Python object overhead and is faster for sampling large batches.
    """
    def __init__(self, size, state_dim):
        self.states  = np.zeros((size, state_dim), dtype=np.float32)
        self.actions = np.zeros((size, 1), dtype=np.int64)
        self.rewards = np.zeros((size, 1), dtype=np.float32)
        self.next_s  = np.zeros((size, state_dim), dtype=np.float32)
        self.dones   = np.zeros((size, 1), dtype=np.float32)
        self.ptr, self.size, self.max_size = 0, 0, size

    def push(self, state, action, reward, next_state, done):
        """Store a transition at the circular buffer pointer."""
        self.states[self.ptr] = state
        self.actions[self.ptr] = action
        self.rewards[self.ptr] = reward
        self.next_s[self.ptr] = next_state
        self.dones[self.ptr] = done
        self.ptr = (self.ptr + 1) % self.max_size
        self.size = min(self.size + 1, self.max_size)

    def sample(self, batch_size):
        """Randomly sample a batch and return tensors on the configured device."""
        idx = np.random.randint(0, self.size, size=batch_size)
        return (
            torch.from_numpy(self.states[idx]).to(device),
            torch.from_numpy(self.actions[idx]).to(device),
            torch.from_numpy(self.rewards[idx]).to(device),
            torch.from_numpy(self.next_s[idx]).to(device),
            torch.from_numpy(self.dones[idx]).to(device)
        )

# --- 2. NETWORK ---
class DQN(nn.Module):
    """A slightly larger MLP used as the function approximator (two hidden layers of 128 units)."""
    def __init__(self, n_inputs, n_actions):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(n_inputs, 128),
            nn.ReLU(),
            nn.Linear(128, 128),
            nn.ReLU(),
            nn.Linear(128, n_actions)
        )
    def forward(self, x): return self.net(x)

# --- 3. TRAINING LOOP ---
def main():
    """
    Training loop with warmup, training only after `MIN_MEMORY_SIZE` samples,
    and a penalty for leaving the play area. Gradient clipping is applied for
    training stability.
    """
    env = gym.make(ENV_NAME)
    n_states = env.observation_space.shape[0]
    n_actions = env.action_space.n
    
    policy_net = DQN(n_states, n_actions).to(device)
    target_net = DQN(n_states, n_actions).to(device)
    target_net.load_state_dict(policy_net.state_dict())
    
    optimizer = optim.Adam(policy_net.parameters(), lr=LEARNING_RATE)
    criterion = nn.SmoothL1Loss() # FIX: More stable than MSE
    
    memory = FastBuffer(MEMORY_SIZE, n_states)
    epsilon = EPSILON_START
    
    print("Collecting experience (Warmup)...")

    for episode in range(1, 500):
        state, _ = env.reset()
        episode_reward = 0
        done = False
        
        while not done:
            # --- ACTION SELECTION ---
            # Random exploration logic
            if random.random() < epsilon:
                action = env.action_space.sample()
            else:
                with torch.no_grad():
                    q_values = policy_net(torch.from_numpy(state).float().unsqueeze(0).to(device))
                    action = q_values.argmax().item()

            # --- STEP ---
            next_state, reward, terminated, truncated, _ = env.step(action)
            done = terminated or truncated

            # Modification: Penalize hitting the wall (crossing boundary)
            # Cart Position is state[0]. Limit is usually approx 2.4
            if terminated and abs(next_state[0]) > 2.0:
                 reward = -10.0 # Strong penalty for crossing boundary
            
            memory.push(state, action, reward, next_state, int(done))
            state = next_state
            episode_reward += reward

            # --- OPTIMIZATION STEP ---
            # FIX: Only train if we have enough data (Prevent overfitting to initial noise)
            if memory.size >= MIN_MEMORY_SIZE:
                s, a, r, ns, d = memory.sample(BATCH_SIZE)
                
                # Q(s, a)
                current_q = policy_net(s).gather(1, a)
                
                # Target Q
                with torch.no_grad():
                    max_next_q = target_net(ns).max(1)[0].unsqueeze(1)
                    target_q = r + (GAMMA * max_next_q * (1 - d))
                
                loss = criterion(current_q, target_q)
                
                optimizer.zero_grad()
                loss.backward()
                # FIX: Clip gradients to prevent "exploding" updates that break the weights
                torch.nn.utils.clip_grad_norm_(policy_net.parameters(), 1.0)
                optimizer.step()
                
                # Decay Epsilon only after training starts
                epsilon = max(EPSILON_END, epsilon * EPSILON_DECAY)

        # Update Target Net
        if episode % TARGET_UPDATE == 0:
            target_net.load_state_dict(policy_net.state_dict())

        if episode % 20 == 0:
            print(f"Ep {episode} | Reward: {episode_reward:.1f} | Epsilon: {epsilon:.2f} | Mem: {memory.size}")

        if episode_reward >= 475:
            print(f"Solved in {episode} episodes!")
            break

    # --- VISUALIZATION ---
    print("\nVisualizing Solution...")
    env = gym.make(ENV_NAME, render_mode="human")
    state, _ = env.reset()
    done = False
    while not done:
        env.render()
        with torch.no_grad():
            action = policy_net(torch.from_numpy(state).float().unsqueeze(0).to(device)).argmax().item()
        state, _, terminated, truncated, _ = env.step(action)
        done = terminated or truncated

    env.close()

if __name__ == "__main__":
    main()