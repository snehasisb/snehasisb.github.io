#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════
  Demo 7 — STREAMING DATABASE (Redis Streams)
  BookHaven: Real-time order event processing
═══════════════════════════════════════════════════════════════════
  ✅ PROS: Real-time processing · Event sourcing · Consumer groups · Replay
  ❌ CONS: Complex architecture · Ordering guarantees · Not for queries
═══════════════════════════════════════════════════════════════════
"""
import redis, json, time, random
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from shared_data import BOOKS, CUSTOMERS

console = Console()

def main():
    console.print(Panel("[bold]Demo 7: STREAMING — Redis Streams[/bold]\nReal-time Order Events", style="bold yellow", width=60))
    r = redis.Redis(host="localhost", port=6379, decode_responses=True)
    r.delete("stream:orders", "stream:pageviews")

    # 1. Produce events
    console.print(Panel("📤 Publishing order events to stream", style="cyan"))
    random.seed(42)
    event_ids = []
    for i in range(8):
        cust = random.choice(CUSTOMERS)
        book = random.choice(BOOKS)
        event = {"customer": cust["name"], "book": book["title"],
                 "price": str(book["price"]), "action": random.choice(["purchase","return","wishlist"])}
        eid = r.xadd("stream:orders", event)
        event_ids.append(eid)
        console.print(f"  → [{eid}] {event['customer']}: {event['action']} '{event['book']}'")

    # 2. Read all events
    console.print(Panel("📥 Reading stream (full history)", style="cyan"))
    events = r.xrange("stream:orders")
    t = Table(title="Order Event Stream")
    t.add_column("ID",style="dim"); t.add_column("Customer",style="cyan")
    t.add_column("Action"); t.add_column("Book"); t.add_column("Price",style="green")
    for eid, data in events:
        t.add_row(eid[:15]+"…", data["customer"], data["action"], data["book"][:25], f"${data['price']}")
    console.print(t)

    # 3. Consumer groups
    console.print(Panel("👥 Consumer Groups (parallel processing)", style="cyan"))
    try: r.xgroup_create("stream:orders", "analytics_team", id="0")
    except: pass
    try: r.xgroup_create("stream:orders", "shipping_team", id="0")
    except: pass

    # Analytics consumer reads
    msgs = r.xreadgroup("analytics_team", "worker1", {"stream:orders": ">"}, count=3)
    if msgs:
        console.print("  [cyan]Analytics Worker[/cyan] processed:")
        for stream, entries in msgs:
            for eid, data in entries:
                console.print(f"    ✓ {data['customer']} → {data['action']}")
                r.xack("stream:orders", "analytics_team", eid)

    # Stream info
    info = r.xinfo_stream("stream:orders")
    console.print(f"\n  Stream length: {info['length']} | Groups: {info['groups']}")

    # 4. Time-range query
    console.print(Panel("⏰ Time-range: Last 5 events", style="cyan"))
    recent = r.xrevrange("stream:orders", count=5)
    for eid, data in recent:
        console.print(f"  [{eid[:15]}] {data['customer']}: {data['action']}")

    console.print(Panel(
        "[green]✅ PROS:[/green] Real-time event processing · Consumer groups · "
        "Event replay · Backpressure handling · Ordering guarantees\n"
        "[red]❌ CONS:[/red] Complex architecture · Not a query engine · "
        "Storage grows unbounded · Requires careful consumer management",
        title="Summary", style="bold magenta"))
    r.close()

if __name__ == "__main__":
    main()
