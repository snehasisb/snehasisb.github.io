#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════
  Demo 1 — RELATIONAL DATABASE (PostgreSQL)
  BookHaven: Orders, Customers, Books with full ACID transactions
═══════════════════════════════════════════════════════════════════
  ✅ PROS: Data integrity · Complex JOINs · ACID transactions · SQL standard
  ❌ CONS: Rigid schema · Vertical scaling · Schema migrations are painful
═══════════════════════════════════════════════════════════════════
"""

import psycopg2
from psycopg2.extras import RealDictCursor
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from shared_data import AUTHORS, BOOKS, CUSTOMERS, ORDERS

console = Console()

DB_CONFIG = {
    "host": "localhost", "port": 5432,
    "dbname": "bookhaven", "user": "fdp", "password": "fdp123"
}


def create_schema(cur):
    """Create normalized relational schema."""
    cur.execute("DROP TABLE IF EXISTS orders, books, authors, customers CASCADE;")

    cur.execute("""
        CREATE TABLE authors (
            id   SERIAL PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            country VARCHAR(60),
            born INTEGER
        );
    """)

    cur.execute("""
        CREATE TABLE books (
            id        SERIAL PRIMARY KEY,
            title     VARCHAR(200) NOT NULL,
            author_id INTEGER REFERENCES authors(id),
            genre     VARCHAR(60),
            price     NUMERIC(8,2),
            year      INTEGER,
            isbn      VARCHAR(20) UNIQUE
        );
    """)

    cur.execute("""
        CREATE TABLE customers (
            id    SERIAL PRIMARY KEY,
            name  VARCHAR(100) NOT NULL,
            email VARCHAR(120) UNIQUE,
            city  VARCHAR(60)
        );
    """)

    cur.execute("""
        CREATE TABLE orders (
            id          SERIAL PRIMARY KEY,
            customer_id INTEGER REFERENCES customers(id),
            book_id     INTEGER REFERENCES books(id),
            quantity    INTEGER DEFAULT 1,
            order_date  DATE DEFAULT CURRENT_DATE
        );
    """)
    console.print("[green]✓ Schema created (4 tables with foreign keys)[/green]")


def insert_data(cur):
    """Insert sample data."""
    for a in AUTHORS:
        cur.execute(
            "INSERT INTO authors (id, name, country, born) VALUES (%s,%s,%s,%s)",
            (a["id"], a["name"], a["country"], a["born"])
        )
    for b in BOOKS:
        cur.execute(
            "INSERT INTO books (id, title, author_id, genre, price, year, isbn) "
            "VALUES (%s,%s,%s,%s,%s,%s,%s)",
            (b["id"], b["title"], b["author_id"], b["genre"], b["price"], b["year"], b["isbn"])
        )
    for c in CUSTOMERS:
        cur.execute(
            "INSERT INTO customers (id, name, email, city) VALUES (%s,%s,%s,%s)",
            (c["id"], c["name"], c["email"], c["city"])
        )
    for o in ORDERS:
        cur.execute(
            "INSERT INTO orders (id, customer_id, book_id, quantity, order_date) "
            "VALUES (%s,%s,%s,%s,%s)",
            (o["id"], o["customer_id"], o["book_id"], o["quantity"], o["date"])
        )
    # Reset serial sequences to avoid duplicate key violations on future auto-generated IDs
    cur.execute("SELECT setval('authors_id_seq', (SELECT MAX(id) FROM authors));")
    cur.execute("SELECT setval('books_id_seq', (SELECT MAX(id) FROM books));")
    cur.execute("SELECT setval('customers_id_seq', (SELECT MAX(id) FROM customers));")
    cur.execute("SELECT setval('orders_id_seq', (SELECT MAX(id) FROM orders));")
    console.print(f"[green]✓ Inserted {len(AUTHORS)} authors, {len(BOOKS)} books, "
                  f"{len(CUSTOMERS)} customers, {len(ORDERS)} orders[/green]")


def demo_queries(cur):
    """Showcase the power of SQL JOINs and aggregations."""

    # ── Query 1: Multi-table JOIN ────────────────────────────────
    console.print(Panel("📊 Query 1: Books with Author info (INNER JOIN)", style="bold cyan"))
    cur.execute("""
        SELECT b.title, a.name AS author, b.genre, b.price, b.year
        FROM books b
        JOIN authors a ON b.author_id = a.id
        ORDER BY b.year;
    """)
    rows = cur.fetchall()
    t = Table(title="Books × Authors JOIN")
    for col in ["title", "author", "genre", "price", "year"]:
        t.add_column(col, style="cyan" if col == "title" else "white")
    for r in rows:
        t.add_row(r["title"], r["author"], r["genre"], f"${r['price']}", str(r["year"]))
    console.print(t)

    # ── Query 2: Aggregation ─────────────────────────────────────
    console.print(Panel("📊 Query 2: Revenue per Customer (JOIN + GROUP BY)", style="bold cyan"))
    cur.execute("""
        SELECT c.name, c.city,
               COUNT(o.id) AS total_orders,
               SUM(o.quantity * b.price) AS total_spent
        FROM customers c
        JOIN orders o ON c.id = o.customer_id
        JOIN books  b ON o.book_id = b.id
        GROUP BY c.id, c.name, c.city
        ORDER BY total_spent DESC;
    """)
    rows = cur.fetchall()
    t = Table(title="Customer Revenue Report")
    t.add_column("Customer", style="cyan")
    t.add_column("City")
    t.add_column("Orders", justify="right")
    t.add_column("Total Spent", justify="right", style="green")
    for r in rows:
        t.add_row(r["name"], r["city"], str(r["total_orders"]), f"${r['total_spent']:.2f}")
    console.print(t)

    # ── Query 3: Subquery — books nobody ordered ─────────────────
    console.print(Panel("📊 Query 3: Unordered Books (Subquery / NOT EXISTS)", style="bold cyan"))
    cur.execute("""
        SELECT b.title, a.name AS author
        FROM books b
        JOIN authors a ON b.author_id = a.id
        WHERE NOT EXISTS (
            SELECT 1 FROM orders o WHERE o.book_id = b.id
        );
    """)
    rows = cur.fetchall()
    if rows:
        for r in rows:
            console.print(f"  📕 {r['title']} by {r['author']}")
    else:
        console.print("  [dim]All books have been ordered![/dim]")


def demo_transaction(conn, cur):
    """ACID transaction demo — atomic transfer."""
    console.print(Panel("🔒 ACID Transaction Demo: Atomic Order Placement", style="bold yellow"))

    try:
        conn.commit()            # End any implicit read transactions
        conn.autocommit = False  # Explicit transaction

        # Simulate placing an order + checking inventory
        cur.execute("INSERT INTO orders (customer_id, book_id, quantity) VALUES (1, 2, 1)")
        console.print("  [yellow]→ Order inserted (not committed yet)[/yellow]")

        # Check: can we also rollback?
        cur.execute("SAVEPOINT before_bad_order")
        cur.execute("INSERT INTO orders (customer_id, book_id, quantity) VALUES (999, 1, 1)")
        console.print("  [red]→ Bad order with non-existent customer — ROLLBACK to savepoint[/red]")

    except psycopg2.errors.ForeignKeyViolation:
        cur.execute("ROLLBACK TO SAVEPOINT before_bad_order")
        console.print("  [green]→ Foreign key violation caught! Rolled back bad order.[/green]")
    
    conn.commit()
    console.print("  [green]✓ Good order committed, bad order rolled back — ACID integrity preserved![/green]")
    conn.autocommit = True


def main():
    console.print(Panel(
        "[bold white]Demo 1: RELATIONAL DATABASE — PostgreSQL[/bold white]\n"
        "BookHaven Online Bookstore — Normalized Schema",
        style="bold blue", width=65
    ))

    conn = psycopg2.connect(**DB_CONFIG, cursor_factory=RealDictCursor)
    cur = conn.cursor()

    try:
        create_schema(cur)
        conn.commit()

        insert_data(cur)
        conn.commit()

        demo_queries(cur)
        demo_transaction(conn, cur)

        # ── Summary ──────────────────────────────────────────────
        console.print(Panel(
            "[green]✅ PROS:[/green] ACID transactions · Powerful JOINs · SQL standard · "
            "Data integrity via FK/UNIQUE constraints\n"
            "[red]❌ CONS:[/red] Rigid schema (ALTER TABLE) · Vertical scaling limits · "
            "Object-relational impedance mismatch · Schema migrations",
            title="Summary", style="bold magenta"
        ))
    finally:
        cur.close()
        conn.close()


if __name__ == "__main__":
    main()
