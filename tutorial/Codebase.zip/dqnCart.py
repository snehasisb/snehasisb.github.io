import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import random
from collections import deque
import gymnasium as gym  # Using gymnasium (the modern standard for OpenAI Gym)

# ==========================================
# 1. Hyperparameters (tweak for learning behaviour)
# ==========================================
# BATCH_SIZE: number of samples drawn from replay buffer per gradient step
BATCH_SIZE = 64         # How many experiences to learn from at once
# GAMMA: reward discount factor (close to 1 favors long-term rewards)
GAMMA = 0.99            # Discount factor (value of future rewards)
# Epsilon schedule: exploration -> exploitation
EPS_START = 1.0         # Initial exploration rate (100% random)
EPS_END = 0.01          # Final exploration rate (1% random)
EPS_DECAY = 0.995       # Rate at which exploration decays per training step
# LR: optimizer learning rate
LR = 0.001              # Learning Rate
# Replay buffer size
MEMORY_SIZE = 10000     # Capacity of the replay buffer
# How often to copy weights from policy net to target net
TARGET_UPDATE = 10      # Update target network every 10 episodes

# Device selection: GPU if available, otherwise CPU
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# ==========================================
# 2. The Brain (Neural Network)
# ==========================================
class DQN(nn.Module):
    """
    The Q-network approximates Q(s, a) for each action given a state s.
    This minimal MLP has two hidden layers with ReLU activations — good enough for CartPole.
    """
    def __init__(self, state_dim, action_dim):
        super(DQN, self).__init__()
        # A simple neural network: Input -> Hidden (64) -> Hidden (64) -> Output (Actions)
        self.net = nn.Sequential(
            nn.Linear(state_dim, 64),
            nn.ReLU(),
            nn.Linear(64, 64),
            nn.ReLU(),
            nn.Linear(64, action_dim)
        )

    def forward(self, x):
        """Forward pass returns raw Q-values for each action."""
        return self.net(x)

# ==========================================
# 3. The Memory (Experience Replay)
# ==========================================
class ReplayBuffer:
    """
    Simple replay buffer using a deque. Stores tuples of (s, a, r, s', done).
    Sampling uniformly breaks the time correlations between consecutive transitions.
    """
    def __init__(self, capacity):
        self.buffer = deque(maxlen=capacity)

    def push(self, state, action, reward, next_state, done):
        """Append a new experience to the buffer."""
        self.buffer.append((state, action, reward, next_state, done))

    def sample(self, batch_size):
        """Return a batch of experiences as torch tensors on the selected device."""
        batch = random.sample(self.buffer, batch_size)
        state, action, reward, next_state, done = zip(*batch)

        # Convert to PyTorch tensors and move to device (CPU/GPU)
        return (torch.FloatTensor(np.array(state)).to(device),
                torch.LongTensor(action).to(device),
                torch.FloatTensor(reward).to(device),
                torch.FloatTensor(np.array(next_state)).to(device),
                torch.FloatTensor(done).to(device))

    def __len__(self):
        return len(self.buffer)

# ==========================================
# 4. The Agent
# ==========================================
class DQNAgent:
    """
    Agent that contains policy and target networks, replay buffer and the training logic.
    - select_action: epsilon-greedy action selection
    - train_step: sample batch, compute TD target, backpropagate
    """
    def __init__(self, state_dim, action_dim):
        self.action_dim = action_dim
        self.epsilon = EPS_START

        # Policy Network: the one we update via gradient descent
        self.policy_net = DQN(state_dim, action_dim).to(device)
        # Target Network: frozen copy used to compute stable targets
        self.target_net = DQN(state_dim, action_dim).to(device)
        self.target_net.load_state_dict(self.policy_net.state_dict())
        self.target_net.eval()  # Target network is used only for inference

        self.optimizer = optim.Adam(self.policy_net.parameters(), lr=LR)
        self.memory = ReplayBuffer(MEMORY_SIZE)

    def select_action(self, state):
        """Epsilon-Greedy Strategy: with probability epsilon choose random action."""
        if random.random() < self.epsilon:
            return random.randint(0, self.action_dim - 1)
        else:
            with torch.no_grad():
                state_t = torch.FloatTensor(state).unsqueeze(0).to(device)  # shape (1, state_dim)
                q_values = self.policy_net(state_t)
                return torch.argmax(q_values).item()

    def train_step(self):
        """Run a single optimization step using a batch sampled from replay buffer."""
        if len(self.memory) < BATCH_SIZE:
            return

        # 1. Sample Batch
        states, actions, rewards, next_states, dones = self.memory.sample(BATCH_SIZE)

        # 2. Compute Current Q (Prediction) for taken actions
        # gather() picks the Q-value for the specific action we took
        current_q = self.policy_net(states).gather(1, actions.unsqueeze(1)).squeeze(1)

        # 3. Compute Target Q using the target network (Bellman backup)
        with torch.no_grad():
            max_next_q = self.target_net(next_states).max(1)[0]
            target_q = rewards + (GAMMA * max_next_q * (1 - dones))

        # 4. Compute Loss (MSE between prediction and target)
        loss = nn.MSELoss()(current_q, target_q)

        # 5. Optimize: gradient descent step
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()

        # Decay exploration rate (epsilon)
        self.epsilon = max(EPS_END, self.epsilon * EPS_DECAY)

    def update_target_network(self):
        """Copy weights from policy net to the target net (hard update)."""
        self.target_net.load_state_dict(self.policy_net.state_dict())

# ==========================================
# 5. Main Loop (Training)
# ==========================================
def run_training():
    """
    Main training loop: create environment, run episodes, and train the DQN agent.
    After training, run a short visualization using the learned policy.
    """
    env = gym.make('CartPole-v1')  # Create Environment
    state_dim = env.observation_space.shape[0]
    action_dim = env.action_space.n

    agent = DQNAgent(state_dim, action_dim)

    num_episodes = 500

    print("Training Started...")

    for episode in range(num_episodes):
        state, _ = env.reset()
        total_reward = 0
        done = False

        while not done:
            # 1. Action selection (epsilon-greedy)
            action = agent.select_action(state)

            # 2. Environment step
            next_state, reward, terminated, truncated, _ = env.step(action)
            done = terminated or truncated

            # 3. Store transition in replay buffer
            agent.memory.push(state, action, reward, next_state, float(done))

            # 4. Advance state and accumulate reward
            state = next_state
            total_reward += reward

            # 5. Perform a training step (if buffer has enough samples)
            agent.train_step()

        # Update Target Network periodically to stabilize learning
        if episode % TARGET_UPDATE == 0:
            agent.update_target_network()

        # Logging
        if episode % 20 == 0:
            print(f"Episode {episode}, Total Reward: {total_reward}, Epsilon: {agent.epsilon:.2f}")

        # Early stopping heuristic (optional)
        if total_reward >= 450:
            print(f"Solved in {episode} episodes!")
            break

    print("Training Complete. Testing Agent...")

    # ==========================================
    # Visualization / Test (run policy with rendering)
    # ==========================================
    env = gym.make('CartPole-v1', render_mode="human")
    state, _ = env.reset()
    done = False
    while not done:
        env.render()
        action = agent.select_action(state)  # Uses greedy policy when epsilon is low
        state, _, terminated, truncated, _ = env.step(action)
        done = terminated or truncated

    env.close()


if __name__ == "__main__":
    run_training()