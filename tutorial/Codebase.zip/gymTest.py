
# ==========================================
# CartPole-v1 Linear Policy Tutorial
# ==========================================
# This script demonstrates a simple linear policy for balancing the pole in CartPole-v1.
# The agent moves left or right based on the pole's angle, using a basic rule.

# --- 1. Imports ---
import gymnasium as gym  # Modern Gym API

# --- 2. Create the CartPole Environment ---
env = gym.make("CartPole-v1", render_mode="human")  # Human rendering for visualization
observation, info = env.reset()  # Initial state

# --- 3. Define the Linear Policy Function ---
def linear_policy(state):
    """
    Simple rule: If pole angle > 0, move right (action=1). If < 0, move left (action=0).
    This keeps the cart under the pole as it falls.
    """
    pole_angle = state[2]
    action = 1 if pole_angle > 0 else 0
    return action

# --- 4. Main Loop: Run the Policy ---
for _ in range(500):
    action = linear_policy(observation)  # Decide action
    observation, reward, terminated, truncated, info = env.step(action)  # Take action
    print(observation, reward, terminated, truncated, info)  # Print step info
    if terminated or truncated:
        observation, info = env.reset()  # Reset if episode ends