#!/usr/bin/env bash
####################################################################
#  BookHaven FDP — One-Click Environment Setup (Ubuntu 22.04/24.04)
#  Usage: chmod +x install.sh && ./install.sh
####################################################################
set -euo pipefail

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

log()  { echo -e "${GREEN}[✓]${NC} $*"; }
warn() { echo -e "${YELLOW}[!]${NC} $*"; }
err()  { echo -e "${RED}[✗]${NC} $*"; }

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# ─── 1. System packages ─────────────────────────────────────────
log "Updating apt cache..."
sudo apt-get update -qq

log "Installing system dependencies..."
sudo apt-get install -y -qq \
    curl wget gnupg lsb-release ca-certificates \
    python3 python3-pip python3-venv

# ─── 2. Docker (if missing) ─────────────────────────────────────
if ! command -v docker &>/dev/null; then
    warn "Docker not found — installing Docker Engine..."
    curl -fsSL https://get.docker.com | sudo sh
    sudo usermod -aG docker "$USER"
    log "Docker installed. You may need to log out/in for group changes."
else
    log "Docker already installed: $(docker --version)"
fi

# Docker Compose plugin
if ! docker compose version &>/dev/null; then
    warn "Installing Docker Compose plugin..."
    sudo apt-get install -y -qq docker-compose-plugin
fi
log "Docker Compose: $(docker compose version --short 2>/dev/null || echo 'available')"

# ─── 3. Python virtual environment ──────────────────────────────
VENV_DIR="$SCRIPT_DIR/.venv"
if [ ! -d "$VENV_DIR" ]; then
    log "Creating Python virtual environment..."
    python3 -m venv "$VENV_DIR"
fi

source "$VENV_DIR/bin/activate"
log "Python venv activated: $VENV_DIR"

log "Installing Python packages..."
pip install --quiet --upgrade pip
pip install --quiet -r "$SCRIPT_DIR/requirements.txt"

# ─── 4. Pull Docker images (background-friendly) ────────────────
log "Pulling Docker images (this may take a few minutes)..."
cd "$SCRIPT_DIR"
docker compose pull

# ─── 5. Start services ──────────────────────────────────────────
log "Starting database services..."
docker compose up -d

echo ""
log "Waiting for services to be healthy..."
sleep 5

# Quick health check
echo -e "\n${GREEN}═══════════════════════════════════════════════════${NC}"
echo -e "${GREEN}  BookHaven FDP — Service Status${NC}"
echo -e "${GREEN}═══════════════════════════════════════════════════${NC}"

check_service() {
    local name=$1 port=$2
    if nc -z localhost "$port" 2>/dev/null; then
        echo -e "  ${GREEN}●${NC} $name (port $port) — UP"
    else
        echo -e "  ${YELLOW}○${NC} $name (port $port) — starting..."
    fi
}

check_service "PostgreSQL"  5432
check_service "MongoDB"     27017
check_service "Redis"       6379
check_service "Cassandra"   9042
check_service "Neo4j"       7687
check_service "InfluxDB"    8086

echo -e "\n${GREEN}═══════════════════════════════════════════════════${NC}"
echo -e "  Activate venv:   ${YELLOW}source .venv/bin/activate${NC}"
echo -e "  Run a demo:      ${YELLOW}python demos/01_relational_postgres.py${NC}"
echo -e "  Open slides:     ${YELLOW}xdg-open slides/index.html${NC}"
echo -e "  Neo4j Browser:   ${YELLOW}http://localhost:7474${NC}"
echo -e "  InfluxDB UI:     ${YELLOW}http://localhost:8086${NC}"
echo -e "${GREEN}═══════════════════════════════════════════════════${NC}"
echo ""
warn "Note: Cassandra takes 1-2 minutes to fully start."
warn "Run 'docker compose logs cassandra' to check status."
