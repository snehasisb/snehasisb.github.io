#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════
  Demo 2 — DOCUMENT DATABASE (MongoDB)
  BookHaven: Flexible book catalog with nested reviews & metadata
═══════════════════════════════════════════════════════════════════
  ✅ PROS: Schema flexibility · Nested documents · Horizontal scaling · JSON-native
  ❌ CONS: No JOINs (denormalized) · Eventual consistency · Data duplication
═══════════════════════════════════════════════════════════════════
"""

from pymongo import MongoClient
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich import print as rprint
import json

from shared_data import AUTHORS, BOOKS, CUSTOMERS, ORDERS

console = Console()


def main():
    console.print(Panel(
        "[bold white]Demo 2: DOCUMENT DATABASE — MongoDB[/bold white]\n"
        "BookHaven — Flexible Book Catalog with Nested Data",
        style="bold green", width=65
    ))

    client = MongoClient("mongodb://localhost:27017")
    db = client["bookhaven"]

    # ── Clean slate ──────────────────────────────────────────────
    db.drop_collection("books")
    db.drop_collection("customers")

    # ── 1. Insert books as rich documents ────────────────────────
    console.print(Panel("📥 Inserting books as DOCUMENTS (nested reviews, tags)", style="bold cyan"))

    book_docs = []
    for b in BOOKS:
        author = next(a for a in AUTHORS if a["id"] == b["author_id"])
        doc = {
            "_id": b["id"],
            "title": b["title"],
            "author": {                         # ← Embedded sub-document
                "name": author["name"],
                "country": author["country"],
            },
            "genre": b["genre"],
            "price": b["price"],
            "year": b["year"],
            "isbn": b["isbn"],
            "description": b["description"],
            "tags": b["tags"],                  # ← Array field
            "reviews": b["reviews"],            # ← Array of sub-documents
        }
        book_docs.append(doc)

    db.books.insert_many(book_docs)
    console.print(f"[green]✓ Inserted {len(book_docs)} book documents[/green]")

    # Show one document
    console.print(Panel("📄 Sample Document Structure", style="bold cyan"))
    sample = db.books.find_one({"_id": 1})
    console.print_json(json.dumps(sample, default=str, indent=2))

    # ── 2. Schema Flexibility Demo ───────────────────────────────
    console.print(Panel("🔄 Schema Flexibility: Adding fields WITHOUT migration", style="bold yellow"))

    # Add a field to just ONE document — no ALTER TABLE needed!
    db.books.update_one(
        {"_id": 1},
        {"$set": {
            "audiobook": {"narrator": "Haruki Murakami", "duration_hrs": 14.5},
            "awards": ["World Fantasy Award 2006"],
        }}
    )
    console.print("[green]✓ Added 'audiobook' and 'awards' to Kafka on the Shore ONLY[/green]")
    console.print("[dim]  → Other documents are unaffected. No schema change needed![/dim]")

    # ── 3. Query nested data ─────────────────────────────────────
    console.print(Panel("🔍 Query: Find books by Japanese authors", style="bold cyan"))

    results = db.books.find({"author.country": "Japan"})  # Dot notation for nested
    t = Table(title="Japanese Author Books")
    t.add_column("Title", style="cyan")
    t.add_column("Author")
    t.add_column("Genre")
    t.add_column("Price", justify="right", style="green")
    for r in results:
        t.add_row(r["title"], r["author"]["name"], r["genre"], f"${r['price']}")
    console.print(t)

    # ── 4. Array queries ─────────────────────────────────────────
    console.print(Panel("🔍 Query: Books tagged 'coming-of-age' (Array Query)", style="bold cyan"))

    results = db.books.find({"tags": "coming-of-age"})
    for r in results:
        console.print(f"  📕 {r['title']} — tags: {r['tags']}")

    # ── 5. Aggregation Pipeline ──────────────────────────────────
    console.print(Panel("📊 Aggregation Pipeline: Average rating per book", style="bold cyan"))

    pipeline = [
        {"$unwind": "$reviews"},                    # Flatten reviews array
        {"$group": {
            "_id": "$title",
            "avg_rating": {"$avg": "$reviews.rating"},
            "num_reviews": {"$sum": 1}
        }},
        {"$sort": {"avg_rating": -1}},
    ]
    results = db.books.aggregate(pipeline)

    t = Table(title="Book Ratings (Aggregation Pipeline)")
    t.add_column("Book", style="cyan")
    t.add_column("Avg Rating", justify="right")
    t.add_column("# Reviews", justify="right")
    for r in results:
        stars = "⭐" * int(r["avg_rating"])
        t.add_row(r["_id"], f"{r['avg_rating']:.1f} {stars}", str(r["num_reviews"]))
    console.print(t)

    # ── 6. Text Search ───────────────────────────────────────────
    console.print(Panel("🔍 Full-Text Search: 'ghost memory'", style="bold cyan"))

    db.books.create_index([("description", "text"), ("title", "text")])
    results = db.books.find(
        {"$text": {"$search": "ghost memory"}},
        {"score": {"$meta": "textScore"}, "title": 1, "description": 1}
    ).sort([("score", {"$meta": "textScore"})])

    for r in results:
        console.print(f"  📕 {r['title']} (relevance: {r['score']:.2f})")
        console.print(f"     [dim]{r['description'][:80]}...[/dim]")

    # ── Summary ──────────────────────────────────────────────────
    console.print(Panel(
        "[green]✅ PROS:[/green] Schema-less flexibility · Nested documents · "
        "Powerful aggregation pipeline · Horizontal scaling (sharding) · JSON-native\n"
        "[red]❌ CONS:[/red] No multi-collection JOINs · Data duplication · "
        "Eventual consistency by default · No foreign key constraints",
        title="Summary", style="bold magenta"
    ))

    client.close()


if __name__ == "__main__":
    main()
