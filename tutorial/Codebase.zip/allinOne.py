import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import make_classification, make_blobs, make_moons
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.cluster import KMeans
from sklearn.semi_supervised import LabelSpreading

# --- Helper for plotting ---
def plot_decision_boundary(model, X, y, title, subplot_pos):
    plt.subplot(subplot_pos)
    
    # Create meshgrid
    x_min, x_max = X[:, 0].min() - 1, X[:, 0].max() + 1
    y_min, y_max = X[:, 1].min() - 1, X[:, 1].max() + 1
    xx, yy = np.meshgrid(np.arange(x_min, x_max, 0.02),
                         np.arange(y_min, y_max, 0.02))
    
    # Predict on meshgrid
    if hasattr(model, "predict"):
        Z = model.predict(np.c_[xx.ravel(), yy.ravel()])
    else: # For clustering models that don't have predict for new data easily
        Z = model.fit_predict(np.c_[xx.ravel(), yy.ravel()])
        
    Z = Z.reshape(xx.shape)
    
    # Plot contours
    plt.contourf(xx, yy, Z, alpha=0.3, cmap=plt.cm.Paired)
    
    # Plot data points
    # Scatter plot colored by the actual labels (y)
    plt.scatter(X[:, 0], X[:, 1], c=y, edgecolors='k', cmap=plt.cm.Paired)
    plt.title(title)

# ==========================================
# 1. SUPERVISED LEARNING VISUALIZATION
# ==========================================
def viz_supervised():
    X, y = make_moons(n_samples=200, noise=0.3, random_state=42)
    model = LogisticRegression()
    model.fit(X, y)
    
    plot_decision_boundary(model, X, y, "1. Supervised (Labels known during training)", 221)

# ==========================================
# 2. UNSUPERVISED LEARNING VISUALIZATION
# ==========================================
def viz_unsupervised():
    # Generate data with clear clusters
    X, _ = make_blobs(n_samples=200, centers=3, n_features=2, random_state=42)
    model = KMeans(n_clusters=3, n_init='auto')
    
    # Notice: We only pass X to fit!
    model.fit(X)
    predicted_labels = model.labels_
    
    plot_decision_boundary(model, X, predicted_labels, "2. Unsupervised (Patterns found, no labels)", 222)

# ==========================================
# 3. SEMI-SUPERVISED LEARNING VISUALIZATION
# ==========================================
def viz_semisupervised():
    X, y = make_moons(n_samples=200, noise=0.2, random_state=42)
    
    # Hide 97% of the labels!
    y_input = np.copy(y)
    n_labeled = 6 # Only 6 labeled points out of 200
    y_input[n_labeled:] = -1
    
    model = LabelSpreading(kernel='rbf', gamma=20)
    model.fit(X, y_input)
    
    # For visualization, we want to distinguish between the few originally labeled points
    # and the ones the model guessed.
    
    plt.subplot(223)
    
    # 1. Plot background colors (the model's inference region)
    # (Simplified for code brevity, re-using the grid logic would be longer)
    
    # 2. Plot the Unlabeled points (Gray) that the model guessed
    unlabeled_mask = (y_input == -1)
    plt.scatter(X[unlabeled_mask, 0], X[unlabeled_mask, 1], c=model.transduction_[unlabeled_mask], 
                marker='.', cmap=plt.cm.Paired, alpha=0.3, label="Guessed Labels")
    
    # 3. Plot the few Labeled points (Solid Colors)
    labeled_mask = (y_input != -1)
    plt.scatter(X[labeled_mask, 0], X[labeled_mask, 1], c=y_input[labeled_mask], 
                marker='o', edgecolors='k', s=100, cmap=plt.cm.Paired, label="Known Labels")
    
    plt.title("3. Semi-Supervised (Labels spread from few dots)")
    plt.legend()

# ==========================================
# 4. REINFORCEMENT LEARNING VISUALIZATION
# ==========================================
def viz_reinforcement():
    plt.subplot(224)
    
    # Grid World: 0 is empty, 1 is treasure, -1 is pit
    grid = np.zeros((5, 5))
    grid[4, 4] = 1  # Treasure at bottom right
    grid[2, 2] = -1 # Pit in the middle
    grid[3, 1] = -1 # Another pit

    # Path taken by a trained agent (hardcoded for visualization example)
    path = [(0,0), (0,1), (0,2), (1,2), (1,3), (2,3), (3,3), (4,3), (4,4)]
    
    # Visualize grid
    plt.imshow(grid, cmap='coolwarm', interpolation='nearest')
    
    # Visualize path
    path_x = [p[1] for p in path]
    path_y = [p[0] for p in path]
    plt.plot(path_x, path_y, marker='o', color='yellow', linewidth=3, markersize=8)
    plt.title("4. Reinforcement (Learning a path via rewards)")
    # Hide axis ticks for cleaner look
    plt.xticks([])
    plt.yticks([])

# --- Run and Show ---
if __name__ == "__main__":
    plt.figure(figsize=(12, 10))
    
    viz_supervised()
    viz_unsupervised()
    viz_semisupervised()
    viz_reinforcement()
    
    plt.tight_layout()
    plt.show()
