
# ==========================================
# CartPole-v1 Random Agent Tutorial
# ==========================================
# This script demonstrates how to interact with the CartPole-v1 environment using random actions.
# It is designed for beginners to understand the basic Gym workflow and environment dynamics.

# --- 1. Imports ---
import gym           # OpenAI Gym for RL environments
import random        # For random action selection

# --- 2. Create the CartPole Environment ---
env = gym.make("CartPole-v1")

# --- 3. Define the Random Agent Loop ---
def Random_games():
    """
    Runs 10 episodes of CartPole using random actions.
    Each episode is independent and resets the environment.
    """
    for episode in range(10):
        env.reset()  # Start a new episode
        # Each episode can last up to 500 steps (frames)
        for t in range(500):
            env.render()  # Display the environment (slow, for visualization)

            # Select a random action (0: left, 1: right)
            action = env.action_space.sample()

            # Take the action and get the results
            next_state, reward, done, info = env.step(action)

            # Print step details: time, state, reward, done flag, info, action
            print(t, next_state, reward, done, info, action)
            if done:
                break  # End episode if done

# --- 4. Run the Random Agent ---
Random_games()