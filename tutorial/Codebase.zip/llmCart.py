import gymnasium as gym
import ollama
import time

# ==========================================
# LLM-Controlled CartPole Tutorial
# ==========================================
# This file demonstrates using an LLM (via Ollama) to control CartPole by converting
# the physics state into a concise natural-language prompt. The LLM returns either '0'
# or '1' to indicate the action. This approach is educational — it's slow and not
# recommended for production RL, but it shows how language models can be used for
# decision-making when mapped carefully to the task.

# --- Configuration ---
# Use a small, fast model to keep per-step latency reasonable.
MODEL_NAME = "qwen3:0.6b"


# ==========================================
# 1. Prompt Engineering: Translate numbers -> English
# ==========================================
def generate_prompt(state):
    """
    Convert the CartPole observation into a tiny, focused instruction for the LLM.
    Observation format: [cart_pos, cart_vel, pole_angle, pole_vel]
    The prompt guides the LLM to output ONLY '0' or '1'.
    """
    cart_pos, cart_vel, pole_angle, pole_vel = state

    # Decide simple human-readable descriptors
    angle_desc = "Leaning RIGHT" if pole_angle > 0 else "Leaning LEFT"
    vel_desc = "Falling FASTER towards the Right" if pole_vel > 0 else "Falling FASTER towards the Left"

    prompt = f"""
    You are an AI controlling a balancing robot. Keep the pole upright.

    CURRENT STATUS:
    - The Pole is {angle_desc}.
    - It is {vel_desc}.

    PHYSICS RULE:
    - If leaning LEFT, you must Push LEFT (Action 0) to get under it.
    - If leaning RIGHT, you must Push RIGHT (Action 1) to get under it.

    COMMAND:
    Based on the status, output ONLY the number '0' or '1'.
    """
    return prompt


# ==========================================
# 2. LLM Caller: Send prompt to Ollama and parse reply
# ==========================================
def get_llm_action(state):
    """Send the generated prompt to the LLM and extract action 0 or 1."""
    prompt = generate_prompt(state)

    try:
        # Call Ollama (this is a blocking network/local call)
        response = ollama.chat(model=MODEL_NAME, messages=[{'role': 'user', 'content': prompt}])

        # The response is expected to contain just '0' or '1' — do a safe parse
        content = response['message']['content'].strip()
        if "0" in content:
            return 0
        if "1" in content:
            return 1
        # Fallback: default safe action
        return 0
    except Exception as e:
        # If the LLM call fails, log and return a safe default
        print(f"LLM Error: {e}")
        return 0


# ==========================================
# 3. Run the simulation using the LLM as the policy
# ==========================================
def run_simulation():
    # Set render_mode to 'human' to see the window (slow)
    env = gym.make('CartPole-v1', render_mode="human")

    print(f"🚀 Starting Direct LLM Control using {MODEL_NAME}...")
    print("NOTE: This will be slower than normal speed due to LLM processing time.")

    state, _ = env.reset()
    done = False
    total_steps = 0

    while not done:
        # Visualize current state
        env.render()

        # Ask the LLM what to do
        action = get_llm_action(state)

        # Execute the action and step the environment
        state, reward, terminated, truncated, _ = env.step(action)
        done = terminated or truncated
        total_steps += 1

        # Periodic status print to observe LLM latency/behavior
        if total_steps % 5 == 0:
            print(f"Step {total_steps}: LLM Chose Action {action}")

    print(f"💥 Game Over. Total Steps Balanced: {total_steps}")
    env.close()


if __name__ == "__main__":
    run_simulation()