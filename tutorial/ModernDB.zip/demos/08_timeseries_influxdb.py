#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════
  Demo 8 — TIMESERIES DATABASE (InfluxDB)
  BookHaven: Book price tracking & page view analytics
═══════════════════════════════════════════════════════════════════
  ✅ PROS: Time-optimized storage · Built-in aggregations · Retention policies
  ❌ CONS: Not general purpose · Limited query patterns · Write-heavy bias
═══════════════════════════════════════════════════════════════════
"""
from influxdb_client import InfluxDBClient, Point, WritePrecision
from influxdb_client.client.write_api import SYNCHRONOUS
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from shared_data import BOOKS, PRICE_HISTORY
import datetime, random

console = Console()
URL = "http://localhost:8086"
TOKEN = "fdp-demo-token-2024"
ORG = "bookhaven"
BUCKET = "bookmetrics"

def main():
    console.print(Panel("[bold]Demo 8: TIMESERIES — InfluxDB[/bold]\nPrice Tracking & Analytics", style="bold cyan", width=60))
    client = InfluxDBClient(url=URL, token=TOKEN, org=ORG)
    write_api = client.write_api(write_options=SYNCHRONOUS)
    query_api = client.query_api()

    # Delete old data
    delete_api = client.delete_api()
    delete_api.delete("1970-01-01T00:00:00Z", "2030-01-01T00:00:00Z",
                      '_measurement="book_price"', bucket=BUCKET, org=ORG)
    delete_api.delete("1970-01-01T00:00:00Z", "2030-01-01T00:00:00Z",
                      '_measurement="page_views"', bucket=BUCKET, org=ORG)

    # 1. Write price history
    console.print(Panel("📥 Writing 12 months of price history", style="cyan"))
    points = []
    for ph in PRICE_HISTORY:
        p = Point("book_price") \
            .tag("book_id", str(ph["book_id"])) \
            .tag("title", ph["title"]) \
            .field("price", ph["price"]) \
            .time(datetime.datetime(ph["year"], ph["month"], 15), WritePrecision.S)
        points.append(p)

    # Page views (hourly for a week)
    random.seed(42)
    for book in BOOKS:
        for day in range(7):
            for hour in range(24):
                views = random.randint(10, 500) if 8 <= hour <= 22 else random.randint(1, 50)
                p = Point("page_views") \
                    .tag("book_id", str(book["id"])) \
                    .tag("title", book["title"]) \
                    .field("views", views) \
                    .time(datetime.datetime(2024, 6, 1+day, hour), WritePrecision.S)
                points.append(p)

    write_api.write(bucket=BUCKET, org=ORG, record=points)
    console.print(f"[green]✓ Wrote {len(points)} data points[/green]")

    # 2. Query: Price trend
    console.print(Panel("📈 Query: Monthly price trend for 'Kafka on the Shore'", style="cyan"))
    query = f'''
        from(bucket: "{BUCKET}")
        |> range(start: 2024-01-01T00:00:00Z, stop: 2024-12-31T23:59:59Z)
        |> filter(fn: (r) => r._measurement == "book_price")
        |> filter(fn: (r) => r.title == "Kafka on the Shore")
        |> sort(columns: ["_time"])
    '''
    tables = query_api.query(query, org=ORG)
    t = Table(title="📈 Price Trend: Kafka on the Shore")
    t.add_column("Month",style="cyan"); t.add_column("Price",style="green")
    for table in tables:
        for record in table.records:
            month_name = record.get_time().strftime("%b %Y")
            bar = "█" * int(record.get_value() * 2)
            t.add_row(month_name, f"${record.get_value():.2f} {bar}")
    console.print(t)

    # 3. Aggregation: Average daily page views
    console.print(Panel("📊 Aggregation: Avg daily page views per book", style="cyan"))
    query = f'''
        from(bucket: "{BUCKET}")
        |> range(start: 2024-06-01T00:00:00Z, stop: 2024-06-08T00:00:00Z)
        |> filter(fn: (r) => r._measurement == "page_views")
        |> group(columns: ["title"])
        |> mean()
    '''
    tables = query_api.query(query, org=ORG)
    t = Table(title="📊 Avg Hourly Page Views (Jun 1-7)")
    t.add_column("Book",style="cyan"); t.add_column("Avg Views/Hour",style="green")
    for table in tables:
        for record in table.records:
            t.add_row(record.values.get("title","?"), f"{record.get_value():.0f}")
    console.print(t)

    # 4. Peak hours
    console.print(Panel("⏰ Peak Traffic Hours (all books combined)", style="cyan"))
    query = f'''
        from(bucket: "{BUCKET}")
        |> range(start: 2024-06-01T00:00:00Z, stop: 2024-06-02T00:00:00Z)
        |> filter(fn: (r) => r._measurement == "page_views")
        |> group(columns: ["_time"])
        |> sum()
        |> sort(columns: ["_value"], desc: true)
        |> limit(n: 5)
    '''
    tables = query_api.query(query, org=ORG)
    for table in tables:
        for record in table.records:
            hour = record.get_time().strftime("%H:%M")
            console.print(f"  🕐 {hour} — {int(record.get_value())} total views")

    console.print(Panel(
        "[green]✅ PROS:[/green] Time-optimized storage · Built-in downsampling · "
        "Retention policies · Flux query language · Fast aggregations\n"
        "[red]❌ CONS:[/red] Not for general-purpose · Limited JOINs · "
        "Write-heavy design · Specialized query language",
        title="Summary", style="bold magenta"))
    client.close()

if __name__ == "__main__":
    main()
