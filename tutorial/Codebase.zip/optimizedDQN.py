import gymnasium as gym
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import random

# --- CONFIGURATION (Tuned for Speed) ---
ENV_NAME = "CartPole-v1"
LEARNING_RATE = 1e-4
GAMMA = 0.99
EPSILON_START = 1.0
EPSILON_END = 0.05
EPSILON_DECAY = 0.995
MEMORY_SIZE = 10000
BATCH_SIZE = 128      # Larger batch for stability
TARGET_UPDATE = 10    # Update target net every 10 episodes
STOP_REWARD = 475     # Solve condition

device = torch.device("cpu") # CPU is faster for CartPole than GPU


# --- 1. VECTORIZED MEMORY (Numpy pre-allocation) ---
class FastBuffer:
    """
    Pre-allocated numpy-backed replay buffer to reduce Python overhead during sampling.
    """
    def __init__(self, size, state_dim, action_dim):
        self.states  = np.zeros((size, state_dim), dtype=np.float32)
        self.actions = np.zeros((size, 1), dtype=np.int64)
        self.rewards = np.zeros((size, 1), dtype=np.float32)
        self.next_s  = np.zeros((size, state_dim), dtype=np.float32)
        self.dones   = np.zeros((size, 1), dtype=np.float32)
        self.ptr, self.size, self.max_size = 0, 0, size

    def push(self, state, action, reward, next_state, done):
        self.states[self.ptr] = state
        self.actions[self.ptr] = action
        self.rewards[self.ptr] = reward
        self.next_s[self.ptr] = next_state
        self.dones[self.ptr] = done
        self.ptr = (self.ptr + 1) % self.max_size
        self.size = min(self.size + 1, self.max_size)

    def sample(self, batch_size):
        idx = np.random.randint(0, self.size, size=batch_size)
        return (
            torch.from_numpy(self.states[idx]).to(device),
            torch.from_numpy(self.actions[idx]).to(device),
            torch.from_numpy(self.rewards[idx]).to(device),
            torch.from_numpy(self.next_s[idx]).to(device),
            torch.from_numpy(self.dones[idx]).to(device)
        )


# --- 2. MINIMAL NETWORK ---
class DQN(nn.Module):
    """A compact MLP used for fast CartPole training."""
    def __init__(self, n_inputs, n_actions):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(n_inputs, 128), nn.ReLU(),
            nn.Linear(128, 128), nn.ReLU(),
            nn.Linear(128, n_actions)
        )
    def forward(self, x): return self.net(x)


# --- 3. OPTIMIZED LOOP ---
def main():
    """
    Training loop tuned for speed: vectorized buffer, larger batch size, CPU device.
    """
    env = gym.make(ENV_NAME)
    n_states, n_actions = env.observation_space.shape[0], env.action_space.n
    
    policy_net = DQN(n_states, n_actions).to(device)
    target_net = DQN(n_states, n_actions).to(device)
    target_net.load_state_dict(policy_net.state_dict())
    
    optimizer = optim.Adam(policy_net.parameters(), lr=LEARNING_RATE)
    memory = FastBuffer(MEMORY_SIZE, n_states, n_actions)
    epsilon = EPSILON_START

    print(f"🚀 Training {ENV_NAME} on {device}...")

    for episode in range(1, 1001):
        state, _ = env.reset()
        episode_reward = 0
        done = False
        
        while not done:
            # Action Selection (Epsilon-Greedy)
            if random.random() < epsilon:
                action = env.action_space.sample()
            else:
                with torch.no_grad():
                    # Unsqueeze adds batch dimension: (4) -> (1, 4)
                    q_values = policy_net(torch.from_numpy(state).float().unsqueeze(0).to(device))
                    action = q_values.argmax().item()

            # Step
            next_state, reward, terminated, truncated, _ = env.step(action)
            done = terminated or truncated
            
            # Fast Store
            memory.push(state, action, reward, next_state, done)
            state = next_state
            episode_reward += reward

            # Train (Vectorized)
            if memory.size > BATCH_SIZE:
                s, a, r, ns, d = memory.sample(BATCH_SIZE)
                
                # Compute Q(s, a)
                current_q = policy_net(s).gather(1, a)
                
                # Compute Q_target = r + gamma * max(Q(s', a'))
                with torch.no_grad():
                    max_next_q = target_net(ns).max(1)[0].unsqueeze(1)
                    target_q = r + (GAMMA * max_next_q * (1 - d))
                
                loss = nn.MSELoss()(current_q, target_q)
                
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()

        # Updates
        epsilon = max(EPSILON_END, epsilon * EPSILON_DECAY)
        if episode % TARGET_UPDATE == 0:
            target_net.load_state_dict(policy_net.state_dict())

        # Logging
        if episode % 20 == 0:
            print(f"Ep {episode:4d} | Reward: {episode_reward:3.0f} | Epsilon: {epsilon:.2f}")
        
        if episode_reward >= STOP_REWARD:
            print(f"✅ Solved in {episode} episodes!")
            break

    # --- VISUALIZATION ---
    print("Running Demo...")
    env = gym.make(ENV_NAME, render_mode="human")
    state, _ = env.reset()
    while True:
        env.render()
        with torch.no_grad():
            action = policy_net(torch.from_numpy(state).float().unsqueeze(0).to(device)).argmax().item()
        state, _, done, _, _ = env.step(action)
        if done: break
    env.close()

if __name__ == "__main__":
    main()

