import torch
import os
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
import time

# ==========================================
# Model Quantization Tutorial
# ==========================================
# This script demonstrates three common approaches to reduce LLM memory footprint:
# 1) Baseline FP32
# 2) PyTorch dynamic quantization (Int8) — great for CPU inference
# 3) BitsAndBytes 4-bit quantization (NF4) — common for GPU deployments

# --- Configuration ---
MODEL_ID = "facebook/opt-125m"  # A tiny model for quick download & testing
PROMPT = "The future of AI is"
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"


def get_model_size_mb(model):
    """Estimate model memory footprint in MB by summing parameter and buffer sizes."""
    param_size = 0
    for param in model.parameters():
        param_size += param.numel() * param.element_size()
    for buffer in model.buffers():
        param_size += buffer.numel() * buffer.element_size()
    return param_size / 1024 / 1024


def generate_text(model, tokenizer, name):
    """Run a short generation to verify the model still behaves correctly after quantization."""
    print(f"\n--- Testing {name} ---")
    start_time = time.time()
    inputs = tokenizer(PROMPT, return_tensors="pt").to(model.device)
    with torch.no_grad():
        outputs = model.generate(**inputs, max_new_tokens=20)
    text = tokenizer.decode(outputs[0], skip_special_tokens=True)
    duration = time.time() - start_time
    print(f"Output: '{text}'")
    print(f"Inference Time: {duration:.4f}s")
    return duration


# ------------------------------------------
# 1) Baseline: load model in full FP32 precision
# ------------------------------------------
print(f"⬇️  Downloading/Loading {MODEL_ID} in Full Precision (FP32)...")
tokenizer = AutoTokenizer.from_pretrained(MODEL_ID)
model_fp32 = AutoModelForCausalLM.from_pretrained(MODEL_ID).to("cpu")  # load to CPU first
size_fp32 = get_model_size_mb(model_fp32)
print(f"📦 FP32 Size: {size_fp32:.2f} MB")
generate_text(model_fp32, tokenizer, "FP32 Model")


# ------------------------------------------
# 2) PyTorch Dynamic Quantization (Int8)
#    Good for CPU — converts Linear layers to int8 kernels
# ------------------------------------------
print("\n🔨 Applying PyTorch Dynamic Quantization (Int8)...")
model_int8 = torch.quantization.quantize_dynamic(
    model_fp32,
    {torch.nn.Linear},
    dtype=torch.qint8
)
size_int8 = get_model_size_mb(model_int8)
print(f"📦 Int8 Size: {size_int8:.2f} MB")
print(f"📉 Reduction: {size_fp32 / size_int8:.1f}x smaller")
generate_text(model_int8, tokenizer, "Int8 Quantized Model")


# ------------------------------------------
# 3) BitsAndBytes 4-bit Quantization (NF4)
#    Typical for GPU inference of large models
# ------------------------------------------
print("\n🔨 Applying BitsAndBytes 4-bit Quantization (NF4)...")

if torch.cuda.is_available():
    bnb_config = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_compute_dtype=torch.float16
    )

    model_4bit = AutoModelForCausalLM.from_pretrained(
        MODEL_ID,
        quantization_config=bnb_config,
        device_map="auto"
    )

    print(f"📦 4-bit Model Loaded on GPU.")
    generate_text(model_4bit, tokenizer, "4-bit Model")
else:
    print("⚠️  Skipping 4-bit test: Requires GPU (CUDA).")
    print("   (BitsAndBytes is primarily for CUDA devices)")


# ------------------------------------------
# Summary: compare sizes (estimates)
# ------------------------------------------
print("\n" + "="*30)
print("FINAL SIZE COMPARISON")
print("="*30)
print(f"Original (FP32): {size_fp32:.2f} MB")
print(f"Dynamic (Int8):  {size_int8:.2f} MB (Standard CPU Method)")
if torch.cuda.is_available():
    print(f"NF4 (4-bit):     ~{size_fp32/4:.2f} MB (Estimated GPU footprint)")
else:
    print("NF4 (4-bit):     Skipped (No GPU)")
print("="*30)
