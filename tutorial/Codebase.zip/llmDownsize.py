import torch
import torch.nn as nn
import torch.optim as optim
from transformers import AutoModelForCausalLM, AutoTokenizer, AutoConfig
import warnings

# Suppress warnings for cleaner console output during tutorial runs
warnings.filterwarnings("ignore")

# ==========================================
# Distillation Tutorial: Teacher -> Micro-Student
# ==========================================
# This script demonstrates a compact knowledge distillation pipeline where a small "student"
# model is trained to mimic a pre-trained "teacher" model (GPT-2). The goal is educational —
# to show how logits matching (soft targets) can transfer knowledge to a much smaller model.

# --- Configuration ---
TEACHER_NAME = "gpt2"  # Teacher model identifier (124M parameters)
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"


# ==========================================
# Create a very small student model (micro student)
# ==========================================
def create_micro_student():
    """
    Build a tiny transformer configuration and instantiate from that config.
    We shrink layers, heads and embedding size aggressively to produce a micro model.
    """
    config = AutoConfig.from_pretrained(TEACHER_NAME)

    # Aggressive compression settings (for demonstration only)
    config.n_layer = 2
    config.n_head = 4
    config.n_embd = 128
    config.vocab_size = 50257  # Match teacher tokenizer

    # Construct model from the modified config (random init)
    model = AutoModelForCausalLM.from_config(config)
    return model


# ==========================================
# Distillation Loop
# ==========================================
def run_distillation():
    print(f"🔧 Loading Teacher: {TEACHER_NAME}...")
    tokenizer = AutoTokenizer.from_pretrained(TEACHER_NAME)

    # GPT-2 doesn't have a pad token by default; set one for batching
    tokenizer.pad_token = tokenizer.eos_token

    # Load the pre-trained teacher model (frozen during distillation)
    teacher = AutoModelForCausalLM.from_pretrained(TEACHER_NAME).to(DEVICE)
    teacher.eval()

    print("👶 Creating Micro-Student...")
    student = create_micro_student().to(DEVICE)

    # Simple size check
    student_params = sum(p.numel() for p in student.parameters())
    print(f"   Teacher Size: ~124 Million Params")
    print(f"   Student Size: {student_params / 1e6:.2f} Million Params")

    # Optimizer & loss for logits-matching (KL divergence)
    optimizer = optim.AdamW(student.parameters(), lr=1e-3)
    criterion = nn.KLDivLoss(reduction="batchmean")
    T = 2.0  # Temperature: softens probability distributions

    print("\n📚 Starting Distillation...")

    # Toy/synthetic prompts to demonstrate the pipeline (not real training data)
    prompts = [
        "Pole left -> Push Left",
        "Pole right -> Push Right",
        "Cart edge -> Stop",
        "Velocity high -> Counteract",
    ] * 20  # small batch of examples

    # Tokenize once for efficiency
    inputs = tokenizer(prompts, return_tensors="pt", padding=True, truncation=True).to(DEVICE)

    student.train()

    # Training loop: for each epoch, compute teacher logits and match them
    for epoch in range(1, 6):
        with torch.no_grad():
            teacher_logits = teacher(**inputs).logits

        student_logits = student(**inputs).logits

        # KLDiv expects log-probs for input and probs for target
        loss = criterion(
            torch.nn.functional.log_softmax(student_logits / T, dim=-1),
            torch.nn.functional.softmax(teacher_logits / T, dim=-1)
        ) * (T * T)

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        print(f"Epoch {epoch} | Distillation Loss: {loss.item():.4f}")

    print("\n✅ Distillation Complete.")

    # Quick sanity check: student can generate tokens without crashing
    with torch.no_grad():
        test_in = tokenizer("Pole left ->", return_tensors="pt").to(DEVICE)
        out = student.generate(**test_in, max_new_tokens=5, pad_token_id=tokenizer.eos_token_id)
        print(f"Test Output: {tokenizer.decode(out[0])}")


if __name__ == "__main__":
    run_distillation()