#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════
  Demo 6 — VECTOR DATABASE (ChromaDB)
  BookHaven: Semantic book search using embeddings
═══════════════════════════════════════════════════════════════════
  ✅ PROS: Semantic understanding · AI-native · Similarity search · Metadata filter
  ❌ CONS: Not for exact queries · Requires embedding models · Newer ecosystem
═══════════════════════════════════════════════════════════════════
"""
import chromadb
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from shared_data import BOOKS, AUTHORS, BOOK_DESCRIPTIONS

console = Console()

def main():
    console.print(Panel("[bold]Demo 6: VECTOR DATABASE — ChromaDB[/bold]\nSemantic Book Search", style="bold green", width=60))

    client = chromadb.Client()  # In-memory, no server needed!

    # Create collection with default embedding function
    console.print(Panel("📥 Creating vector collection + embeddings", style="cyan"))
    console.print("  [dim]Using ChromaDB's built-in sentence-transformer embeddings[/dim]")

    collection = client.create_collection(
        name="bookhaven_books",
        metadata={"hnsw:space": "cosine"}
    )

    # Add books with metadata
    ids, documents, metadatas = [], [], []
    for i, book in enumerate(BOOKS):
        author = next(a for a in AUTHORS if a["id"] == book["author_id"])
        ids.append(f"book_{book['id']}")
        documents.append(BOOK_DESCRIPTIONS[i])
        metadatas.append({
            "title": book["title"],
            "author": author["name"],
            "genre": book["genre"],
            "year": book["year"],
            "price": book["price"],
        })

    collection.add(ids=ids, documents=documents, metadatas=metadatas)
    console.print(f"[green]✓ Added {len(ids)} books with auto-generated embeddings[/green]")

    # Semantic Search 1
    console.print(Panel("🔍 Semantic Search: 'magical stories about family across generations'", style="bold yellow"))
    results = collection.query(
        query_texts=["magical stories about family across generations"],
        n_results=3,
    )
    t = Table(title="Search Results (Cosine Similarity)")
    t.add_column("Rank",style="yellow"); t.add_column("Book",style="cyan")
    t.add_column("Author"); t.add_column("Distance",style="green")
    for i in range(len(results["ids"][0])):
        meta = results["metadatas"][0][i]
        dist = results["distances"][0][i]
        t.add_row(str(i+1), meta["title"], meta["author"], f"{dist:.4f}")
    console.print(t)

    # Semantic Search 2
    console.print(Panel("🔍 Semantic Search: 'war and identity crisis in Africa'", style="bold yellow"))
    results = collection.query(query_texts=["war and identity crisis in Africa"], n_results=3)
    for i in range(len(results["ids"][0])):
        meta = results["metadatas"][0][i]
        console.print(f"  {i+1}. 📕 {meta['title']} by {meta['author']} (dist: {results['distances'][0][i]:.4f})")

    # Semantic Search 3 — with metadata filter
    console.print(Panel("🔍 Filtered Search: 'love and loss' in genre=Romance or Literary Fiction", style="bold yellow"))
    results = collection.query(
        query_texts=["love and loss and nostalgia"],
        n_results=3,
        where={"genre": {"$in": ["Romance", "Literary Fiction"]}}
    )
    for i in range(len(results["ids"][0])):
        meta = results["metadatas"][0][i]
        console.print(f"  {i+1}. 📕 {meta['title']} ({meta['genre']}) — dist: {results['distances'][0][i]:.4f}")

    # Show why vector DB matters
    console.print(Panel("💡 Why Vector DB? — Traditional vs Semantic Search", style="bold cyan"))
    console.print("  [yellow]SQL:[/yellow]  SELECT * FROM books WHERE description LIKE '%family%'")
    console.print("  → Misses: 'One Hundred Years of Solitude' (uses 'generations', 'Buendía')")
    console.print("")
    console.print("  [green]Vector:[/green] query('magical stories about family across generations')")
    console.print("  → FINDS: 'One Hundred Years of Solitude' — understands MEANING, not keywords!")

    console.print(Panel(
        "[green]✅ PROS:[/green] Semantic understanding · AI/LLM native · Similarity search · "
        "Metadata filtering · No keyword matching needed\n"
        "[red]❌ CONS:[/red] Not for exact lookups · Requires embedding computation · "
        "Approximate results · Newer ecosystem · Index rebuild costs",
        title="Summary", style="bold magenta"))

if __name__ == "__main__":
    main()
