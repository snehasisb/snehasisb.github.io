#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════
  Demo 3 — KEY-VALUE DATABASE (Redis)
  BookHaven: Shopping cart, session cache, leaderboard
═══════════════════════════════════════════════════════════════════
  ✅ PROS: Sub-millisecond latency · Simple API · Rich data structures · TTL
  ❌ CONS: Memory-bound · Limited querying · No complex relationships
═══════════════════════════════════════════════════════════════════
"""
import redis, json, time
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from shared_data import BOOKS

console = Console()

def main():
    console.print(Panel("[bold]Demo 3: KEY-VALUE — Redis[/bold]\nCaching, Cart, Leaderboard", style="bold red", width=60))
    r = redis.Redis(host="localhost", port=6379, decode_responses=True)
    r.flushdb()

    # 1. Session Cache with TTL
    console.print(Panel("🔑 Session Cache (SET/GET + TTL)", style="cyan"))
    r.setex("session:alice", 3600, json.dumps({"user_id":1,"name":"Alice","cart":3}))
    console.print(f"  GET → {r.get('session:alice')}")
    console.print(f"  TTL → {r.ttl('session:alice')}s")
    start = time.perf_counter()
    for _ in range(10000): r.get("session:alice")
    ms = (time.perf_counter()-start)*1000
    console.print(f"  [green]⚡ 10K reads in {ms:.1f}ms[/green]")

    # 2. Hash: Book Cache
    console.print(Panel("📦 Book Cache (HASH)", style="cyan"))
    for b in BOOKS:
        r.hset(f"book:{b['id']}", mapping={"title":b["title"],"genre":b["genre"],"price":str(b["price"])})
    t = Table(title="Cached Books")
    t.add_column("Key",style="cyan"); t.add_column("Title"); t.add_column("Price",style="green")
    for i in range(1,len(BOOKS)+1):
        d = r.hgetall(f"book:{i}")
        t.add_row(f"book:{i}", d["title"], f"${d['price']}")
    console.print(t)

    # 3. Sorted Set: Leaderboard
    console.print(Panel("🏆 Bestseller Leaderboard (SORTED SET)", style="cyan"))
    sales = {"Kafka on the Shore":1520,"Half of a Yellow Sun":2340,"100 Years of Solitude":5100,
             "Beloved":3200,"The Kite Runner":4800,"Norwegian Wood":980}
    for title, cnt in sales.items(): r.zadd("bestsellers", {title: cnt})
    t = Table(title="🏆 Top Sellers")
    t.add_column("Rank",style="yellow"); t.add_column("Book",style="cyan"); t.add_column("Sales",style="green")
    for rank,(title,score) in enumerate(r.zrevrange("bestsellers",0,4,withscores=True),1):
        t.add_row(["🥇","🥈","🥉","4","5"][rank-1], title, f"{int(score):,}")
    console.print(t)

    # 4. List: Shopping Cart
    console.print(Panel("🛒 Shopping Cart (LIST)", style="cyan"))
    for b in BOOKS[:3]: r.rpush("cart:alice", json.dumps({"id":b["id"],"title":b["title"]}))
    for item in r.lrange("cart:alice",0,-1): console.print(f"  🛒 {json.loads(item)['title']}")

    console.print(Panel(
        "[green]✅ PROS:[/green] Sub-ms latency · Rich structures · TTL · Atomic ops\n"
        "[red]❌ CONS:[/red] Memory-bound · No complex queries · No relationships",
        title="Summary", style="bold magenta"))
    r.close()

if __name__ == "__main__":
    main()
