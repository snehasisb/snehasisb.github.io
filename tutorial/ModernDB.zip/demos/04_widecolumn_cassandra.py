#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════
  Demo 4 — WIDE-COLUMN DATABASE (Cassandra)
  BookHaven: User activity log — massive write throughput
═══════════════════════════════════════════════════════════════════
  ✅ PROS: Linear scalability · Write-optimized · No SPOF · Multi-DC
  ❌ CONS: Limited query patterns · No ad-hoc queries · Denormalized
═══════════════════════════════════════════════════════════════════
"""
from cassandra.cluster import Cluster
from cassandra.query import SimpleStatement
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from shared_data import BOOKS, CUSTOMERS
import uuid, datetime

console = Console()

def main():
    console.print(Panel("[bold]Demo 4: WIDE-COLUMN — Cassandra[/bold]\nUser Activity Log", style="bold magenta", width=60))
    cluster = Cluster(["localhost"], port=9042)
    session = cluster.connect()

    # Create keyspace & table
    session.execute("""CREATE KEYSPACE IF NOT EXISTS bookhaven
        WITH replication = {'class':'SimpleStrategy','replication_factor':1}""")
    session.set_keyspace("bookhaven")

    session.execute("DROP TABLE IF EXISTS user_activity")
    session.execute("""
        CREATE TABLE user_activity (
            user_id    INT,
            activity_time TIMESTAMP,
            activity_type TEXT,
            book_id    INT,
            book_title TEXT,
            details    TEXT,
            PRIMARY KEY (user_id, activity_time)
        ) WITH CLUSTERING ORDER BY (activity_time DESC)
    """)
    console.print("[green]✓ Table created with partition key (user_id) + clustering key (activity_time)[/green]")

    # Insert activity data
    console.print(Panel("📥 Insert user activities (write-optimized)", style="cyan"))
    activities = ["view","view","add_to_cart","purchase","review","view","wishlist"]
    import random; random.seed(42)
    base = datetime.datetime(2024,1,1)
    for cust in CUSTOMERS:
        for i in range(10):
            book = random.choice(BOOKS)
            ts = base + datetime.timedelta(days=random.randint(0,180), hours=random.randint(0,23))
            session.execute(
                "INSERT INTO user_activity (user_id,activity_time,activity_type,book_id,book_title,details) "
                "VALUES (%s,%s,%s,%s,%s,%s)",
                (cust["id"], ts, random.choice(activities), book["id"], book["title"], f"From {cust['city']}")
            )
    console.print(f"[green]✓ Inserted {len(CUSTOMERS)*10} activity records[/green]")

    # Query by partition key (FAST)
    console.print(Panel("🔍 Query: Alice's recent activity (partition key lookup = FAST)", style="cyan"))
    rows = session.execute("SELECT * FROM user_activity WHERE user_id=1 LIMIT 5")
    t = Table(title="Alice's Activity (Partition Scan)")
    t.add_column("Time",style="cyan"); t.add_column("Action"); t.add_column("Book"); t.add_column("Details")
    for row in rows:
        t.add_row(str(row.activity_time)[:19], row.activity_type, row.book_title, row.details)
    console.print(t)

    # Time-range query within partition
    console.print(Panel("🔍 Query: Alice's activity in Jan-Mar 2024 (range on clustering key)", style="cyan"))
    rows = session.execute(
        "SELECT * FROM user_activity WHERE user_id=1 AND activity_time >= '2024-01-01' AND activity_time < '2024-04-01'"
    )
    for row in rows:
        console.print(f"  [{row.activity_type:12s}] {str(row.activity_time)[:10]} — {row.book_title}")

    # Show what DOESN'T work (anti-pattern)
    console.print(Panel("⚠️  Anti-Pattern: Query without partition key", style="bold yellow"))
    console.print("  [red]SELECT * FROM user_activity WHERE activity_type='purchase'[/red]")
    console.print("  → Requires ALLOW FILTERING (full cluster scan = SLOW)")
    console.print("  → Solution: Create a separate table partitioned by activity_type!")

    console.print(Panel(
        "[green]✅ PROS:[/green] Linear scaling · Massive write throughput · No SPOF · Multi-datacenter\n"
        "[red]❌ CONS:[/red] Query-driven design · No ad-hoc queries · Denormalization required · No JOINs",
        title="Summary", style="bold magenta"))
    cluster.shutdown()

if __name__ == "__main__":
    main()
