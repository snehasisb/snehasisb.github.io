"""
BookHaven — Shared Sample Data
═══════════════════════════════
Common book/author/customer data used across ALL database demos.
This ensures every demo tells the same story with the same data.
"""

# ── Authors ──────────────────────────────────────────────────────
AUTHORS = [
    {"id": 1, "name": "Haruki Murakami",    "country": "Japan",   "born": 1949},
    {"id": 2, "name": "Chimamanda Adichie", "country": "Nigeria", "born": 1977},
    {"id": 3, "name": "Gabriel García Márquez", "country": "Colombia", "born": 1927},
    {"id": 4, "name": "Toni Morrison",      "country": "USA",     "born": 1931},
    {"id": 5, "name": "Khaled Hosseini",    "country": "Afghanistan", "born": 1965},
]

# ── Books ────────────────────────────────────────────────────────
BOOKS = [
    {
        "id": 1, "title": "Kafka on the Shore", "author_id": 1,
        "genre": "Magical Realism", "price": 14.99, "year": 2002,
        "isbn": "978-1400079278",
        "description": "A teenage boy runs away from home and a aging man who talks to cats embark on parallel odysseys.",
        "tags": ["surreal", "coming-of-age", "philosophy", "Japan"],
        "reviews": [
            {"user": "alice", "rating": 5, "text": "A mesmerizing, dreamlike journey"},
            {"user": "bob",   "rating": 4, "text": "Beautifully weird and profound"},
        ]
    },
    {
        "id": 2, "title": "Half of a Yellow Sun", "author_id": 2,
        "genre": "Historical Fiction", "price": 12.99, "year": 2006,
        "isbn": "978-1400095209",
        "description": "A sweeping story set during the Nigerian Civil War told through three intertwined lives.",
        "tags": ["war", "love", "identity", "Africa"],
        "reviews": [
            {"user": "charlie", "rating": 5, "text": "Devastating and beautiful"},
            {"user": "diana",   "rating": 5, "text": "Essential reading about Nigeria"},
        ]
    },
    {
        "id": 3, "title": "One Hundred Years of Solitude", "author_id": 3,
        "genre": "Magical Realism", "price": 13.50, "year": 1967,
        "isbn": "978-0060883287",
        "description": "Seven generations of the Buendía family in the mythical town of Macondo.",
        "tags": ["family-saga", "surreal", "Latin-America", "classic"],
        "reviews": [
            {"user": "eve",   "rating": 5, "text": "The greatest novel ever written"},
            {"user": "frank", "rating": 4, "text": "Dense but rewarding"},
        ]
    },
    {
        "id": 4, "title": "Beloved", "author_id": 4,
        "genre": "Literary Fiction", "price": 11.99, "year": 1987,
        "isbn": "978-1400033416",
        "description": "A formerly enslaved woman is haunted by the ghost of her deceased daughter.",
        "tags": ["slavery", "ghost-story", "memory", "trauma"],
        "reviews": [
            {"user": "grace", "rating": 5, "text": "Haunting and unforgettable"},
            {"user": "henry", "rating": 5, "text": "Poetic and painful masterpiece"},
        ]
    },
    {
        "id": 5, "title": "The Kite Runner", "author_id": 5,
        "genre": "Literary Fiction", "price": 10.99, "year": 2003,
        "isbn": "978-1594631931",
        "description": "A story of friendship, betrayal, and redemption set against the backdrop of Afghanistan.",
        "tags": ["friendship", "redemption", "Afghanistan", "coming-of-age"],
        "reviews": [
            {"user": "ivan",  "rating": 5, "text": "Heartbreaking and hopeful"},
            {"user": "julia", "rating": 4, "text": "Powerful story of guilt and forgiveness"},
        ]
    },
    {
        "id": 6, "title": "Norwegian Wood", "author_id": 1,
        "genre": "Romance", "price": 13.99, "year": 1987,
        "isbn": "978-0375704024",
        "description": "A nostalgic story of loss and sexuality set in 1960s Tokyo.",
        "tags": ["love", "loss", "nostalgia", "Japan", "coming-of-age"],
        "reviews": [
            {"user": "alice", "rating": 4, "text": "Bittersweet and tender"},
        ]
    },
]

# ── Customers ────────────────────────────────────────────────────
CUSTOMERS = [
    {"id": 1, "name": "Alice Johnson",   "email": "alice@example.com",   "city": "New York"},
    {"id": 2, "name": "Bob Williams",    "email": "bob@example.com",     "city": "London"},
    {"id": 3, "name": "Charlie Brown",   "email": "charlie@example.com", "city": "Tokyo"},
    {"id": 4, "name": "Diana Prince",    "email": "diana@example.com",   "city": "Paris"},
    {"id": 5, "name": "Eve Martinez",    "email": "eve@example.com",     "city": "Mumbai"},
]

# ── Orders ───────────────────────────────────────────────────────
ORDERS = [
    {"id": 1, "customer_id": 1, "book_id": 1, "quantity": 1, "date": "2024-01-15"},
    {"id": 2, "customer_id": 1, "book_id": 3, "quantity": 2, "date": "2024-01-16"},
    {"id": 3, "customer_id": 2, "book_id": 2, "quantity": 1, "date": "2024-02-01"},
    {"id": 4, "customer_id": 3, "book_id": 1, "quantity": 1, "date": "2024-02-10"},
    {"id": 5, "customer_id": 3, "book_id": 5, "quantity": 1, "date": "2024-02-10"},
    {"id": 6, "customer_id": 4, "book_id": 4, "quantity": 3, "date": "2024-03-05"},
    {"id": 7, "customer_id": 5, "book_id": 3, "quantity": 1, "date": "2024-03-12"},
    {"id": 8, "customer_id": 5, "book_id": 6, "quantity": 1, "date": "2024-03-12"},
    {"id": 9, "customer_id": 2, "book_id": 6, "quantity": 1, "date": "2024-03-20"},
    {"id": 10, "customer_id": 1, "book_id": 4, "quantity": 1, "date": "2024-04-01"},
]

# ── Book descriptions for Vector Search ──────────────────────────
BOOK_DESCRIPTIONS = [
    f"{b['title']} by {next(a['name'] for a in AUTHORS if a['id']==b['author_id'])}. "
    f"{b['description']} Genre: {b['genre']}. Tags: {', '.join(b['tags'])}."
    for b in BOOKS
]

# ── Price history for TimeSeries ─────────────────────────────────
import random
random.seed(42)

PRICE_HISTORY = []
for book in BOOKS:
    base = book["price"]
    for month in range(1, 13):
        delta = round(random.uniform(-2.0, 2.0), 2)
        price = round(max(5.0, base + delta), 2)
        PRICE_HISTORY.append({
            "book_id": book["id"],
            "title": book["title"],
            "price": price,
            "month": month,
            "year": 2024,
        })
