import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import random
from collections import deque
import gymnasium as gym
import ollama
import time

# ==========================================
# LLM-Guided DQN Tutorial
# ==========================================
# This script integrates an LLM as a "judge" to modify rewards and guide a standard DQN.
# The LLM (via Ollama) can provide shaped rewards or critique the agent's state. This
# is experimental and primarily illustrative.

# --- CONFIG ---
MODEL_NAME = "qwen3:0.6b"
TRAIN_EPISODES = 15        # Keep small for demos — increase for real experiments
RENDER_AFTER_TRAIN = True

# For CartPole it's typically faster to run on CPU due to small model size and GPU overhead
device = torch.device("cpu")


# ==========================================
# LLM Judge: turns state into a small textual prompt and asks LLM for a scalar reward
# ==========================================
class LLM_Judge:
    def __init__(self, model_name):
        self.model = model_name
        print(f"⚖️  Initializing LLM Judge using {model_name}...")

    def state_to_text(self, state):
        """Create a concise human-readable status for the LLM."""
        cart_pos, cart_vel, pole_angle, pole_vel = state
        status = []
        status.append("dangerously near the edge" if abs(cart_pos) > 2.0 else "safely in the middle")
        if abs(pole_angle) < 0.05:
            status.append("perfectly upright")
        elif pole_angle > 0:
            status.append("leaning right")
        else:
            status.append("leaning left")
        return ", ".join(status)

    def get_reward(self, state, done, original_reward):
        """Query the LLM for a reward in range [-1.0, 1.0]. Returns a fallback on error."""
        if done:
            return -5.0  # strong penalty for terminal failures

        description = self.state_to_text(state)
        prompt = f"""
        Situation: Cart is {description}.
        Rate performance from -1.0 (bad) to 1.0 (good).
        Output ONLY the number.
        """

        try:
            response = ollama.chat(model=self.model, messages=[{'role': 'user', 'content': prompt}])
            content = response['message']['content'].strip()
            # Extract float robustly
            import re
            match = re.search(r"[-+]?\d*\.\d+|\d+", content)
            if match:
                val = float(match.group())
                return max(-1.0, min(1.0, val))
            return 0.0
        except Exception:
            return 0.0


# ==========================================
# Small DQN used as the agent brain
# ==========================================
class DQN(nn.Module):
    def __init__(self, state_dim, action_dim):
        super(DQN, self).__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim, 64),
            nn.ReLU(),
            nn.Linear(64, 64),
            nn.ReLU(),
            nn.Linear(64, action_dim)
        )
    def forward(self, x): return self.net(x)


class Agent:
    """A minimal DQN agent with replay memory and epsilon-greedy policy."""
    def __init__(self, state_dim, action_dim):
        self.policy_net = DQN(state_dim, action_dim).to(device)
        self.target_net = DQN(state_dim, action_dim).to(device)
        self.target_net.load_state_dict(self.policy_net.state_dict())
        self.optimizer = optim.Adam(self.policy_net.parameters(), lr=0.001)
        self.memory = deque(maxlen=10000)
        self.epsilon = 1.0

    def select_action(self, state):
        if random.random() < self.epsilon:
            return random.randint(0, 1)
        with torch.no_grad():
            state_t = torch.FloatTensor(state).unsqueeze(0).to(device)
            return torch.argmax(self.policy_net(state_t)).item()

    def train_step(self, batch_size=32):
        if len(self.memory) < batch_size:
            return
        batch = random.sample(self.memory, batch_size)
        state, action, reward, next_state, done = zip(*batch)
        state_t = torch.FloatTensor(np.array(state)).to(device)
        action_t = torch.LongTensor(action).to(device)
        reward_t = torch.FloatTensor(reward).to(device)
        next_state_t = torch.FloatTensor(np.array(next_state)).to(device)
        done_t = torch.FloatTensor(done).to(device)
        curr_q = self.policy_net(state_t).gather(1, action_t.unsqueeze(1)).squeeze(1)
        with torch.no_grad():
            next_q = self.target_net(next_state_t).max(1)[0]
            target_q = reward_t + 0.99 * next_q * (1 - done_t)
        loss = nn.MSELoss()(curr_q, target_q)
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()


# ==========================================
# Training loop: use LLM to shape rewards occasionally
# ==========================================
def main():
    env = gym.make('CartPole-v1')
    agent = Agent(4, 2)
    judge = LLM_Judge(MODEL_NAME)
    print(f"\n🚀 Starting Training for {TRAIN_EPISODES} episodes...")

    for episode in range(1, TRAIN_EPISODES + 1):
        state, _ = env.reset()
        total_reward = 0
        done = False
        step_count = 0
        while not done:
            action = agent.select_action(state)
            next_state, reward, terminated, truncated, _ = env.step(action)
            done = terminated or truncated
            # Query LLM every 10 steps to avoid too much latency
            if step_count % 10 == 0:
                reward = judge.get_reward(next_state, done, reward)
            else:
                reward = 0.1
            agent.memory.append((state, action, reward, next_state, float(done)))
            state = next_state
            total_reward += reward
            step_count += 1
            agent.train_step()
        agent.epsilon = max(0.05, agent.epsilon * 0.9)
        if episode % 5 == 0:
            agent.target_net.load_state_dict(agent.policy_net.state_dict())
            print(f"   Episode {episode}: Total Reward (LLM Modified): {total_reward:.2f}")
    env.close()
    print("\n✅ Training Complete!")

    # Visualization
    if RENDER_AFTER_TRAIN:
        print("\n🎥 Starting Visualization (Look for the popup window)...")
        viz_env = gym.make('CartPole-v1', render_mode="human")
        state, _ = viz_env.reset()
        done = False
        while not done:
            viz_env.render()
            with torch.no_grad():
                state_t = torch.FloatTensor(state).unsqueeze(0).to(device)
                action = torch.argmax(agent.policy_net(state_t)).item()
            state, _, terminated, truncated, _ = viz_env.step(action)
            done = terminated or truncated
            time.sleep(0.05)
        viz_env.close()
        print("🎬 Visualization Finished.")


if __name__ == "__main__":
    main()

