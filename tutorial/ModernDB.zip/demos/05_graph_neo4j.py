#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════
  Demo 5 — GRAPH DATABASE (Neo4j)
  BookHaven: Book recommendations, author networks, social graph
═══════════════════════════════════════════════════════════════════
  ✅ PROS: Relationship-first · Pattern matching · Traversals · Cypher
  ❌ CONS: Not for bulk analytics · Learning curve · Scaling limitations
═══════════════════════════════════════════════════════════════════
"""
from neo4j import GraphDatabase
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from shared_data import AUTHORS, BOOKS, CUSTOMERS, ORDERS

console = Console()
URI = "bolt://localhost:7687"
AUTH = ("neo4j", "fdp12345")

def main():
    console.print(Panel("[bold]Demo 5: GRAPH DATABASE — Neo4j[/bold]\nRecommendations & Relationships", style="bold blue", width=60))
    driver = GraphDatabase.driver(URI, auth=AUTH)

    with driver.session() as s:
        # Clean
        s.run("MATCH (n) DETACH DELETE n")

        # Create nodes & relationships
        console.print(Panel("📥 Building the BookHaven Knowledge Graph", style="cyan"))
        for a in AUTHORS:
            s.run("CREATE (a:Author {id:$id, name:$name, country:$country, born:$born})",
                  id=a["id"], name=a["name"], country=a["country"], born=a["born"])
        for b in BOOKS:
            s.run("CREATE (b:Book {id:$id, title:$title, genre:$genre, price:$price, year:$year})",
                  id=b["id"], title=b["title"], genre=b["genre"], price=b["price"], year=b["year"])
            s.run("""MATCH (b:Book {id:$bid}), (a:Author {id:$aid})
                     CREATE (a)-[:WROTE]->(b)""", bid=b["id"], aid=b["author_id"])
        for c in CUSTOMERS:
            s.run("CREATE (c:Customer {id:$id, name:$name, city:$city})",
                  id=c["id"], name=c["name"], city=c["city"])
        for o in ORDERS:
            s.run("""MATCH (c:Customer {id:$cid}), (b:Book {id:$bid})
                     CREATE (c)-[:PURCHASED {quantity:$qty, date:$date}]->(b)""",
                  cid=o["customer_id"], bid=o["book_id"], qty=o["quantity"], date=o["date"])

        # Genre nodes + relationships
        genres = set(b["genre"] for b in BOOKS)
        for g in genres:
            s.run("CREATE (g:Genre {name:$name})", name=g)
            s.run("""MATCH (b:Book {genre:$g}), (g:Genre {name:$g}) CREATE (b)-[:IN_GENRE]->(g)""", g=g)

        # SIMILAR_TO relationships between books sharing genre
        s.run("""MATCH (b1:Book)-[:IN_GENRE]->(g:Genre)<-[:IN_GENRE]-(b2:Book)
                 WHERE b1.id < b2.id CREATE (b1)-[:SIMILAR_TO {via:g.name}]->(b2)""")

        console.print("[green]✓ Graph created: Authors, Books, Customers, Genres + relationships[/green]")

        # Query 1: Author -> Books
        console.print(Panel("🔍 Cypher: What did Murakami write?", style="cyan"))
        result = s.run("MATCH (a:Author {name:'Haruki Murakami'})-[:WROTE]->(b:Book) RETURN b.title, b.year ORDER BY b.year")
        for r in result:
            console.print(f"  📕 {r['b.title']} ({r['b.year']})")

        # Query 2: Recommendation — "Customers who bought X also bought Y"
        console.print(Panel("🎯 RECOMMENDATION: Customers who bought 'Kafka on the Shore' also bought...", style="bold yellow"))
        result = s.run("""
            MATCH (target:Book {title:'Kafka on the Shore'})<-[:PURCHASED]-(c:Customer)-[:PURCHASED]->(other:Book)
            WHERE other <> target
            RETURN other.title AS book, COUNT(c) AS co_purchases, COLLECT(c.name) AS buyers
            ORDER BY co_purchases DESC
        """)
        t = Table(title="🎯 Collaborative Filtering")
        t.add_column("Recommended Book", style="cyan"); t.add_column("Co-purchases", style="green"); t.add_column("Buyers")
        for r in result:
            t.add_row(r["book"], str(r["co_purchases"]), ", ".join(r["buyers"]))
        console.print(t)

        # Query 3: Shortest path
        console.print(Panel("🔗 Shortest Path: Alice → Beloved", style="cyan"))
        result = s.run("""
            MATCH path = shortestPath(
                (c:Customer {name:'Alice Johnson'})-[*]-(b:Book {title:'Beloved'})
            ) RETURN [n IN nodes(path) | 
                CASE WHEN n:Customer THEN '👤'+n.name
                     WHEN n:Book THEN '📕'+n.title
                     WHEN n:Author THEN '✍️'+n.name
                     WHEN n:Genre THEN '🏷️'+n.name
                END] AS path_nodes
        """)
        for r in result:
            console.print(f"  Path: {' → '.join(r['path_nodes'])}")

        # Query 4: Graph analytics — most connected book
        console.print(Panel("📊 Graph Analytics: Most connected nodes", style="cyan"))
        result = s.run("""
            MATCH (b:Book)-[r]-()
            RETURN b.title AS book, COUNT(r) AS connections
            ORDER BY connections DESC LIMIT 5
        """)
        t = Table(title="Most Connected Books")
        t.add_column("Book", style="cyan"); t.add_column("Connections", style="green")
        for r in result:
            t.add_row(r["book"], str(r["connections"]))
        console.print(t)

    console.print(Panel(
        "[green]✅ PROS:[/green] Relationship-first model · Cypher query language · "
        "Pattern matching · Shortest path · Real-time recommendations\n"
        "[red]❌ CONS:[/red] Not for bulk analytics · Horizontal scaling challenges · "
        "Learning curve · Overkill for simple data",
        title="Summary", style="bold magenta"))
    driver.close()

if __name__ == "__main__":
    main()
