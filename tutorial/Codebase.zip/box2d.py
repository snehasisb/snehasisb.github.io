

# ==========================================
# LunarLander-v3 PID Controller Tutorial
# ==========================================
# This script demonstrates how to use a simple PID controller to solve the LunarLander-v3 environment in OpenAI Gymnasium.
# It is designed for educational purposes, with detailed comments explaining each step and concept.

# --- 1. Imports ---
import gymnasium as gym  # RL environment library
import numpy as np       # For numerical operations
import warnings          # To suppress warnings for clean output

# --- 2. Suppress warnings for clarity ---
warnings.filterwarnings("ignore")



# ==========================================
# 3. Simple PID Agent Class
# ==========================================
class SimplePIDAgent:
    """
    A simple PID Controller for LunarLander-v3.
    This agent uses proportional and derivative logic to control the lander's vertical and horizontal movement.
    """
    def __init__(self):
        # No initialization needed for this stateless agent
        pass

    def get_action(self, state):
        """
        Given the current state, decide which engine to fire.
        State vector: [x, y, vel_x, vel_y, angle, angular_vel, left_leg, right_leg]
        Returns: action (int) - 0: Do nothing, 1: Left engine, 2: Main engine, 3: Right engine
        """
        # --- Unpack state variables ---
        x, y, vx, vy, angle, omega, left_leg, right_leg = state

        # --- VERTICAL CONTROL (Hover/Descend) ---
        # Target vertical velocity is lower if lander is off-center or not landed
        target_vy = -0.4 * np.abs(x) - (0.05 if left_leg or right_leg else 0.3)
        # Fire main engine if falling too fast
        main_engine = 1.0 if (vy < target_vy) else 0.0

        # --- HORIZONTAL CONTROL (Stabilize Angle) ---
        # Target angle compensates for horizontal position and velocity
        target_angle = (x * 0.5) + (vx * 1.0)
        angle_error = target_angle - angle
        # D-term: Add angular velocity for damping
        angle_correction = angle_error + (omega * 1.0)

        # --- ACTION DECISION ---
        action = 0  # Default: Do nothing
        if main_engine > 0.5:
            action = 2 # Fire Main Engine (Up)
        elif angle_correction > 0.1:
            action = 3 # Fire Right Engine (Push Left)
        elif angle_correction < -0.1:
            action = 1 # Fire Left Engine (Push Right)
        # Return the chosen action
        return action


# ==========================================
# 4. Run Live Demo Function
# ==========================================
def run_live_demo():
    """
    Runs the LunarLander-v3 environment for 3 episodes using the SimplePIDAgent.
    Renders the environment and prints results for each episode.
    """
    print("🚀 Initializing LunarLander-v3...")

    try:
        # Create the environment with human rendering
        env = gym.make("LunarLander-v3", render_mode="human")
    except Exception as e:
        print(f"❌ Error: {e}")
        print("Try updating gymnasium: pip install --upgrade gymnasium")
        return

    agent = SimplePIDAgent()  # Instantiate the agent

    # --- Run multiple episodes ---
    for episode in range(1, 4):
        state, _ = env.reset()  # Reset environment
        total_reward = 0
        steps = 0
        done = False

        print(f"\n🎬 Episode {episode} Started...")

        # --- Main episode loop ---
        while not done:
            action = agent.get_action(state)  # Get action from agent
            state, reward, terminated, truncated, _ = env.step(action)  # Take action
            done = terminated or truncated    # Check if episode finished
            total_reward += reward            # Accumulate reward
            steps += 1

        # --- Check landing success ---
        if state[6] == 1 and state[7] == 1:
            print(f"✅ Episode {episode}: LANDED! (Score: {total_reward:.1f})")
        else:
            print(f"💥 Episode {episode}: CRASHED. (Score: {total_reward:.1f})")

    env.close()  # Close environment
    print("\n👋 Simulation Closed.")


# ==========================================
# 5. Main Entry Point
# ==========================================
if __name__ == "__main__":
    # Run the live demo when the script is executed directly
    run_live_demo()
