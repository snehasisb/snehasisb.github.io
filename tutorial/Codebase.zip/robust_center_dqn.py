import gymnasium as gym
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import random

# --- CONFIGURATION ---
ENV_NAME = "CartPole-v1"
BATCH_SIZE = 64
GAMMA = 0.99
EPSILON_START = 1.0
EPSILON_END = 0.01
EPSILON_DECAY = 0.997  # Slower decay to explore "Left" AND "Right" thoroughly
TAU = 0.005            # Soft Update rate (Stability Magic)
LR = 1e-3
MEMORY_SIZE = 10000
MIN_MEMORY = 1000      # Warmup

device = torch.device("cpu")


# --- 1. REPLAY BUFFER ---
class ReplayBuffer:
    """Pre-allocated numpy-backed replay buffer for speed and deterministic memory usage."""
    def __init__(self, size, state_dim):
        self.states  = np.zeros((size, state_dim), dtype=np.float32)
        self.actions = np.zeros((size, 1), dtype=np.int64)
        self.rewards = np.zeros((size, 1), dtype=np.float32)
        self.next_s  = np.zeros((size, state_dim), dtype=np.float32)
        self.dones   = np.zeros((size, 1), dtype=np.float32)
        self.ptr, self.size, self.max_size = 0, 0, size

    def push(self, state, action, reward, next_state, done):
        self.states[self.ptr] = state
        self.actions[self.ptr] = action
        self.rewards[self.ptr] = reward
        self.next_s[self.ptr] = next_state
        self.dones[self.ptr] = done
        self.ptr = (self.ptr + 1) % self.max_size
        self.size = min(self.size + 1, self.max_size)

    def sample(self, batch_size):
        idx = np.random.randint(0, self.size, size=batch_size)
        return (
            torch.from_numpy(self.states[idx]).to(device),
            torch.from_numpy(self.actions[idx]).to(device),
            torch.from_numpy(self.rewards[idx]).to(device),
            torch.from_numpy(self.next_s[idx]).to(device),
            torch.from_numpy(self.dones[idx]).to(device)
        )


# --- 2. NETWORK ---
class DQN(nn.Module):
    """Slightly wider network for better stability and representation capacity."""
    def __init__(self, n_inputs, n_actions):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(n_inputs, 128),
            nn.ReLU(),
            nn.Linear(128, 128),
            nn.ReLU(),
            nn.Linear(128, n_actions)
        )

    def forward(self, x):
        return self.net(x)


# --- 3. TRAINING LOOP ---
def main():
    """Training loop with reward shaping and soft updates for stability."""
    env = gym.make(ENV_NAME)
    n_states = env.observation_space.shape[0]
    n_actions = env.action_space.n

    policy_net = DQN(n_states, n_actions).to(device)
    target_net = DQN(n_states, n_actions).to(device)
    target_net.load_state_dict(policy_net.state_dict()) # Clone initially

    optimizer = optim.AdamW(policy_net.parameters(), lr=LR, amsgrad=True)
    criterion = nn.SmoothL1Loss()
    memory = ReplayBuffer(MEMORY_SIZE, n_states)
    
    epsilon = EPSILON_START
    print("Collecting Experience...")

    for episode in range(1, 500):
        state, _ = env.reset()
        episode_reward = 0
        done = False
        
        while not done:
            # A. Select Action
            if random.random() < epsilon:
                action = env.action_space.sample()
            else:
                with torch.no_grad():
                    q_values = policy_net(torch.from_numpy(state).float().unsqueeze(0).to(device))
                    action = q_values.argmax().item()

            # B. Step
            next_state, reward, terminated, truncated, _ = env.step(action)
            done = terminated or truncated
            
            # --- CRITICAL FIX: REWARD SHAPING ---
            # 1. Standard Survival Bonus
            r = 1.0 
            
            # 2. Penalty for drifting away from center (x=0)
            # Cart position is next_state[0]
            dist_from_center = abs(next_state[0])
            r -= dist_from_center * 0.1  # Gentle nudge to stay middle
            
            # 3. Death Penalty (Boundary or Angle Fail)
            if terminated:
                r = -10.0
            
            memory.push(state, action, r, next_state, int(done))
            state = next_state
            episode_reward += reward # Track the *original* reward for logging, not the shaped one

            # C. Train
            if memory.size >= MIN_MEMORY:
                s, a, r_batch, ns, d = memory.sample(BATCH_SIZE)
                
                # Double DQN Logic (Optional but good):
                # We stick to Standard DQN here but with Soft Updates below
                curr_q = policy_net(s).gather(1, a)
                
                with torch.no_grad():
                    max_next_q = target_net(ns).max(1)[0].unsqueeze(1)
                    target_q = r_batch + (GAMMA * max_next_q * (1 - d))
                
                loss = criterion(curr_q, target_q)
                
                optimizer.zero_grad()
                loss.backward()
                torch.nn.utils.clip_grad_norm_(policy_net.parameters(), 1.0)
                optimizer.step()

                # --- SOFT UPDATE ---
                # Slowly move Target Net parameters towards Policy Net
                # theta_target = theta_target * (1 - tau) + theta_policy * tau
                for target_param, policy_param in zip(target_net.parameters(), policy_net.parameters()):
                    target_param.data.copy_(
                        target_param.data * (1.0 - TAU) + policy_param.data * TAU
                    )

                epsilon = max(EPSILON_END, epsilon * EPSILON_DECAY)

        if episode % 20 == 0:
            print(f"Ep {episode} | Reward: {episode_reward:.1f} | Epsilon: {epsilon:.2f}")
        
        if episode_reward >= 475:
            print(f"✅ Solved in {episode} episodes!")
            break

    env.close()
    
    # D. Visualize
    print("\nVisualizing...")
    env = gym.make(ENV_NAME, render_mode="human")
    state, _ = env.reset()
    done = False
    while not done:
        env.render()
        with torch.no_grad():
             action = policy_net(torch.from_numpy(state).float().unsqueeze(0).to(device)).argmax().item()
        state, _, terminated, truncated, _ = env.step(action)
        done = terminated or truncated
    env.close()

if __name__ == "__main__":
    main()

