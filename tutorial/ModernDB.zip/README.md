# BookHaven — Modern Database Landscape FDP Package

This repository contains the complete package for a **4-Hour (2+2) Faculty Development Program (FDP)** on Database Architectures, comparing Relational, Document, Key-Value, Wide-Column, Graph, Vector, Streaming, and Time-Series databases using a single cohesive bookstore use case (**BookHaven**).

---
## 🛠️ Unified Use Case: BookHaven Online Bookstore

To make database comparisons intuitive and concrete, every single demo interacts with the same bookstore model:
- **Relational:** Highly normalized tables connected by foreign keys.
- **Document:** Nested reviews, genre arrays, and polymorphic fields.
- **Key-Value:** Shopping carts, fast session states, and best-seller lists.
- **Wide-Column:** Chronological clickstream user-activity logs.
- **Graph:** Recommendation networks ("who bought X also bought Y") and paths.
- **Vector:** AI semantic search ("stories about generations of magic in Latin America").
- **Streaming:** Real-time order event streams.
- **Time-Series:** 12-month book price histories and hourly traffic page-view metrics.

---

## 🚀 Getting Started on Ubuntu

### 1. Run Setup Script
Execute the setup script. It installs Docker Engine (if missing), updates Python dependencies in a local virtual environment, and pulls the database container images.

```bash
chmod +x install.sh
./install.sh
```

### 2. Activate Python Environment
```bash
source .venv/bin/activate
```

---

## 💻 Running the Live Demos

Ensure you have activated the virtual environment (`source .venv/bin/activate`) before running:

### 1. Relational (PostgreSQL)
```bash
python demos/01_relational_postgres.py
```

### 2. Document (MongoDB)
```bash
python demos/02_document_mongodb.py
```

### 3. Key-Value (Redis)
```bash
python demos/03_keyvalue_redis.py
```

### 4. Wide-Column (Cassandra)
```bash
python demos/04_widecolumn_cassandra.py
```

### 5. Graph (Neo4j)
```bash
python demos/05_graph_neo4j.py
```

### 6. Vector (ChromaDB)
```bash
python demos/06_vector_chromadb.py
```

### 7. Streaming (Redis Streams)
```bash
python demos/07_streaming_redis_streams.py
```

### 8. Time-Series (InfluxDB)
```bash
python demos/08_timeseries_influxdb.py
```

---

## 📊 Summary Comparison Matrix

| Database Type | Primary Advantage | Main Disadvantage | Best Use Case | Demo Tech |
| :--- | :--- | :--- | :--- | :--- |
| **Relational** | Unmatched consistency & ACID safety | Rigid schema migrations | Financial systems, checkout | PostgreSQL |
| **Document** | High schema flexibility & nesting | Duplication risk, lack of JOINs | Dynamic catalogs, CMS | MongoDB |
| **Key-Value** | Sub-millisecond read/write speeds | Memory-bound, no deep querying | Sessions, caching, counters | Redis |
| **Wide-Column** | Infinite scalability, fast writes | Rigid query paths, no ad-hoc JOINs | Ingestion, log pipelines | Cassandra |
| **Graph** | Fast relation traversals & paths | Scaling limits, slower bulk scan | Social nets, recommendations | Neo4j |
| **Vector** | Semantic similarity & AI relevance | Approximate matching, model cost | Semantic search, RAG | ChromaDB |
| **Streaming** | Real-time event consumption | High structural complexity | Event-driven notification | Redis Streams |
| **Time-Series** | High-density temporal storage | Specialized query syntax, append-only | IoT monitoring, price logs | InfluxDB |


